var networks = {"galFiltered.sif(1)": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "galFiltered.sif(1)",
    "name" : "galFiltered.sif(1)",
    "SUID" : 1451,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "222",
        "shared_name" : "YBR019C",
        "gal1RGsig" : 0.098603,
        "gal80Rexp" : 2.856,
        "gal1RGexp" : 0.061,
        "gal4RGsig" : 3.3164E-11,
        "name" : "YBR019C",
        "COMMON" : "GAL10",
        "SUID" : 222,
        "gal4RGexp" : -1.993,
        "selected" : false,
        "gal80Rsig" : 3.9398E-18
      },
      "position" : {
        "x" : -6.008908863884699,
        "y" : -1416.1922826327525
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "265",
        "shared_name" : "YJR048W",
        "gal1RGsig" : 3.3444E-5,
        "gal80Rexp" : -0.643,
        "gal1RGexp" : 0.216,
        "gal4RGsig" : 0.005959,
        "name" : "YJR048W",
        "COMMON" : "CYC1",
        "SUID" : 265,
        "gal4RGexp" : 0.14,
        "selected" : false,
        "gal80Rsig" : 1.6071E-8
      },
      "position" : {
        "x" : 173.43309247888874,
        "y" : -1597.060412362977
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "233",
        "shared_name" : "YBR018C",
        "gal1RGsig" : 7.8855E-4,
        "gal80Rexp" : 3.126,
        "gal1RGexp" : 0.153,
        "gal4RGsig" : 3.6284E-11,
        "name" : "YBR018C",
        "COMMON" : "GAL7",
        "SUID" : 233,
        "gal4RGexp" : -1.995,
        "selected" : false,
        "gal80Rsig" : 3.9427E-17
      },
      "position" : {
        "x" : 164.05397260584186,
        "y" : -1384.2254704989634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "shared_name" : "?",
        "name" : "?",
        "SUID" : 375,
        "selected" : false
      },
      "position" : {
        "x" : -72.09686052404095,
        "y" : -1585.0952977694712
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "231",
        "shared_name" : "YPL248C",
        "gal1RGsig" : 0.11614,
        "gal80Rexp" : -0.211,
        "gal1RGexp" : 0.1,
        "gal4RGsig" : 1.264E-4,
        "name" : "YPL248C",
        "COMMON" : "GAL4",
        "SUID" : 231,
        "gal4RGexp" : -0.758,
        "selected" : false,
        "gal80Rsig" : 0.088214
      },
      "position" : {
        "x" : 49.49711608886719,
        "y" : -1489.548583984375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "630",
        "shared_name" : "YOR120W",
        "gal1RGsig" : 9.0303E-5,
        "gal80Rexp" : 0.576,
        "gal1RGexp" : 0.194,
        "gal4RGsig" : 1.8298E-5,
        "name" : "YOR120W",
        "COMMON" : "GCY1",
        "SUID" : 630,
        "gal4RGexp" : -0.349,
        "selected" : false,
        "gal80Rsig" : 6.3927E-9
      },
      "position" : {
        "x" : -50.83375322423626,
        "y" : -1505.7339696444712
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "229",
        "shared_name" : "YLR081W",
        "gal1RGsig" : 2.4597E-4,
        "gal80Rexp" : 0.892,
        "gal1RGexp" : 0.176,
        "gal4RGsig" : 1.6652E-7,
        "name" : "YLR081W",
        "COMMON" : "GAL2",
        "SUID" : 229,
        "gal4RGexp" : -0.57,
        "selected" : false,
        "gal80Rsig" : 7.3429E-10
      },
      "position" : {
        "x" : 76.54855346679688,
        "y" : -1409.010986328125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "483",
        "shared_name" : "YML051W",
        "gal1RGsig" : 0.080275,
        "gal80Rexp" : -1.167,
        "gal1RGexp" : -0.07,
        "gal4RGsig" : 4.3863E-8,
        "name" : "YML051W",
        "COMMON" : "GAL80",
        "SUID" : 483,
        "gal4RGexp" : -0.606,
        "selected" : false,
        "gal80Rsig" : 8.1952E-17
      },
      "position" : {
        "x" : 178.9628471175606,
        "y" : -1494.6999425448619
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "227",
        "shared_name" : "YBR020W",
        "gal1RGsig" : 7.0101E-9,
        "gal80Rexp" : 2.939,
        "gal1RGexp" : -2.426,
        "gal4RGsig" : 2.5038E-9,
        "name" : "YBR020W",
        "COMMON" : "GAL1",
        "SUID" : 227,
        "gal4RGexp" : -2.406,
        "selected" : false,
        "gal80Rsig" : 2.8147E-18
      },
      "position" : {
        "x" : -33.9830299576347,
        "y" : -1377.2427434481822
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "225",
        "shared_name" : "YGL035C",
        "gal1RGsig" : 1.102E-7,
        "gal80Rexp" : -0.28,
        "gal1RGexp" : 0.345,
        "gal4RGsig" : 1.7172E-6,
        "name" : "YGL035C",
        "COMMON" : "MIG1",
        "SUID" : 225,
        "gal4RGexp" : 0.31,
        "selected" : false,
        "gal80Rsig" : 0.0070533
      },
      "position" : {
        "x" : -128.27950822911907,
        "y" : -1463.1631383456431
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "223",
        "shared_name" : "YOL051W",
        "gal1RGsig" : 0.001834,
        "gal80Rexp" : 0.111,
        "gal1RGexp" : 0.171,
        "gal4RGsig" : 0.33923,
        "name" : "YOL051W",
        "COMMON" : "GAL11",
        "SUID" : 223,
        "gal4RGexp" : 0.055,
        "selected" : false,
        "gal80Rsig" : 0.30922
      },
      "position" : {
        "x" : 69.69892883300781,
        "y" : -1325.6220703125
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "226",
        "source" : "222",
        "target" : "225",
        "shared_name" : "YBR019C (pd) YGL035C",
        "name" : "YBR019C (pd) YGL035C",
        "interaction" : "pd",
        "SUID" : 226,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "224",
        "source" : "222",
        "target" : "223",
        "shared_name" : "YBR019C (pd) YOL051W",
        "name" : "YBR019C (pd) YOL051W",
        "interaction" : "pd",
        "SUID" : 224,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "398",
        "source" : "375",
        "target" : "225",
        "shared_name" : "? (pd) YGL035C",
        "name" : "? (pd) YGL035C",
        "interaction" : "pd",
        "SUID" : 398,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "571",
        "source" : "231",
        "target" : "233",
        "shared_name" : "YPL248C (pd) YBR018C",
        "name" : "YPL248C (pd) YBR018C",
        "interaction" : "pd",
        "SUID" : 571,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "570",
        "source" : "231",
        "target" : "229",
        "shared_name" : "YPL248C (pd) YLR081W",
        "name" : "YPL248C (pd) YLR081W",
        "interaction" : "pd",
        "SUID" : 570,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "569",
        "source" : "231",
        "target" : "227",
        "shared_name" : "YPL248C (pd) YBR020W",
        "name" : "YPL248C (pd) YBR020W",
        "interaction" : "pd",
        "SUID" : 569,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "567",
        "source" : "231",
        "target" : "483",
        "shared_name" : "YPL248C (pd) YML051W",
        "name" : "YPL248C (pd) YML051W",
        "interaction" : "pd",
        "SUID" : 567,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "566",
        "source" : "231",
        "target" : "225",
        "shared_name" : "YPL248C (pd) YGL035C",
        "name" : "YPL248C (pd) YGL035C",
        "interaction" : "pd",
        "SUID" : 566,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "565",
        "source" : "231",
        "target" : "265",
        "shared_name" : "YPL248C (pd) YJR048W",
        "name" : "YPL248C (pd) YJR048W",
        "interaction" : "pd",
        "SUID" : 565,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "564",
        "source" : "231",
        "target" : "375",
        "shared_name" : "YPL248C (pd) ?",
        "name" : "YPL248C (pd) ?",
        "interaction" : "pd",
        "SUID" : 564,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "563",
        "source" : "231",
        "target" : "222",
        "shared_name" : "YPL248C (pd) YBR019C",
        "name" : "YPL248C (pd) YBR019C",
        "interaction" : "pd",
        "SUID" : 563,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "631",
        "source" : "630",
        "target" : "231",
        "shared_name" : "YOR120W (pd) YPL248C",
        "name" : "YOR120W (pd) YPL248C",
        "interaction" : "pd",
        "SUID" : 631,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "561",
        "source" : "227",
        "target" : "225",
        "shared_name" : "YBR020W (pd) YGL035C",
        "name" : "YBR020W (pd) YGL035C",
        "interaction" : "pd",
        "SUID" : 561,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "234",
        "source" : "223",
        "target" : "233",
        "shared_name" : "YOL051W (pd) YBR018C",
        "name" : "YOL051W (pd) YBR018C",
        "interaction" : "pd",
        "SUID" : 234,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "230",
        "source" : "223",
        "target" : "229",
        "shared_name" : "YOL051W (pd) YLR081W",
        "name" : "YOL051W (pd) YLR081W",
        "interaction" : "pd",
        "SUID" : 230,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "228",
        "source" : "223",
        "target" : "227",
        "shared_name" : "YOL051W (pd) YBR020W",
        "name" : "YOL051W (pd) YBR020W",
        "interaction" : "pd",
        "SUID" : 228,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    } ]
  }
},"myGraph": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "myGraph",
    "name" : "myGraph",
    "SUID" : 1506,
    "__Annotations" : [ ],
    "selected" : false
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "1519",
        "shared_name" : "node 3",
        "score" : 5,
        "name" : "node 3",
        "SUID" : 1519,
        "id_original" : "node 3",
        "selected" : false,
        "group" : "B"
      },
      "position" : {
        "x" : 19.831741333007812,
        "y" : -90.4530143737793
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1518",
        "shared_name" : "node 2",
        "score" : 15,
        "name" : "node 2",
        "SUID" : 1518,
        "id_original" : "node 2",
        "selected" : false,
        "group" : "B"
      },
      "position" : {
        "x" : 92.10902404785156,
        "y" : -11.212383270263672
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1517",
        "shared_name" : "node 1",
        "score" : 10,
        "name" : "node 1",
        "SUID" : 1517,
        "id_original" : "node 1",
        "selected" : false,
        "group" : "A"
      },
      "position" : {
        "x" : -97.21867370605469,
        "y" : 88.02606582641602
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1516",
        "shared_name" : "node 0",
        "score" : 20,
        "name" : "node 0",
        "SUID" : 1516,
        "id_original" : "node 0",
        "selected" : false,
        "group" : "A"
      },
      "position" : {
        "x" : -14.722091674804688,
        "y" : 13.639331817626953
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "1523",
        "source" : "1518",
        "target" : "1519",
        "shared_name" : "node 2 (interacts) node 3",
        "shared_interaction" : "interacts",
        "name" : "node 2 (interacts) node 3",
        "interaction" : "interacts",
        "weight" : 9.9,
        "data_key_column" : 1523,
        "SUID" : 1523,
        "source_original" : "node 2",
        "selected" : false,
        "target_original" : "node 3"
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1522",
        "source" : "1516",
        "target" : "1519",
        "shared_name" : "node 0 (activates) node 3",
        "shared_interaction" : "activates",
        "name" : "node 0 (activates) node 3",
        "interaction" : "activates",
        "weight" : 5.2,
        "data_key_column" : 1522,
        "SUID" : 1522,
        "source_original" : "node 0",
        "selected" : false,
        "target_original" : "node 3"
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1521",
        "source" : "1516",
        "target" : "1518",
        "shared_name" : "node 0 (interacts) node 2",
        "shared_interaction" : "interacts",
        "name" : "node 0 (interacts) node 2",
        "interaction" : "interacts",
        "weight" : 3.0,
        "data_key_column" : 1521,
        "SUID" : 1521,
        "source_original" : "node 0",
        "selected" : false,
        "target_original" : "node 2"
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1520",
        "source" : "1516",
        "target" : "1517",
        "shared_name" : "node 0 (inhibits) node 1",
        "shared_interaction" : "inhibits",
        "name" : "node 0 (inhibits) node 1",
        "interaction" : "inhibits",
        "weight" : 5.1,
        "data_key_column" : 1520,
        "SUID" : 1520,
        "source_original" : "node 0",
        "selected" : false,
        "target_original" : "node 1"
      },
      "selected" : false
    } ]
  }
},"galFiltered.sif": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "galFiltered.sif",
    "name" : "galFiltered.sif",
    "SUID" : 52,
    "__Annotations" : [ ],
    "selected" : false
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "752",
        "shared_name" : "YDL194W",
        "gal1RGsig" : 0.018043,
        "gal80Rexp" : 0.449,
        "gal1RGexp" : 0.139,
        "gal4RGsig" : 0.033961,
        "name" : "YDL194W",
        "COMMON" : "SNF3",
        "SUID" : 752,
        "gal4RGexp" : 0.333,
        "selected" : false,
        "gal80Rsig" : 0.011348
      },
      "position" : {
        "x" : 412.01829755701374,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "750",
        "shared_name" : "YDR277C",
        "gal1RGsig" : 2.186E-5,
        "gal80Rexp" : 0.448,
        "gal1RGexp" : 0.243,
        "gal4RGsig" : 0.028044,
        "name" : "YDR277C",
        "COMMON" : "MTH1",
        "SUID" : 750,
        "gal4RGexp" : 0.192,
        "selected" : false,
        "gal80Rsig" : 5.727E-4
      },
      "position" : {
        "x" : 212.01829755701374,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "748",
        "shared_name" : "YBR043C",
        "gal1RGsig" : 5.373E-8,
        "gal80Rexp" : 0.0,
        "gal1RGexp" : 0.454,
        "gal4RGsig" : 0.94178,
        "name" : "YBR043C",
        "COMMON" : "YBR043C",
        "SUID" : 748,
        "gal4RGexp" : 0.023,
        "selected" : false,
        "gal80Rsig" : 0.999999
      },
      "position" : {
        "x" : 12.018297557013739,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "744",
        "shared_name" : "YPR145W",
        "gal1RGsig" : 3.174E-5,
        "gal80Rexp" : -0.232,
        "gal1RGexp" : -0.195,
        "gal4RGsig" : 1.1525E-7,
        "name" : "YPR145W",
        "COMMON" : "ASN1",
        "SUID" : 744,
        "gal4RGexp" : -0.614,
        "selected" : false,
        "gal80Rsig" : 0.0011873
      },
      "position" : {
        "x" : -187.98170244298626,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "741",
        "shared_name" : "YER054C",
        "gal1RGsig" : 0.16958,
        "gal80Rexp" : 0.247,
        "gal1RGexp" : 0.057,
        "gal4RGsig" : 6.2032E-4,
        "name" : "YER054C",
        "COMMON" : "GIP2",
        "SUID" : 741,
        "gal4RGexp" : 0.206,
        "selected" : false,
        "gal80Rsig" : 0.0043603
      },
      "position" : {
        "x" : -287.98170244298626,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "738",
        "shared_name" : "YBR045C",
        "gal1RGsig" : 5.5911E-6,
        "gal80Rexp" : 0.94,
        "gal1RGexp" : 0.786,
        "gal4RGsig" : 1.2945E-5,
        "name" : "YBR045C",
        "COMMON" : "GIP1",
        "SUID" : 738,
        "gal4RGexp" : 1.022,
        "selected" : false,
        "gal80Rsig" : 0.016389
      },
      "position" : {
        "x" : -387.98170244298626,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "736",
        "shared_name" : "YBL079W",
        "gal1RGsig" : 2.5668E-4,
        "gal80Rexp" : -0.42,
        "gal1RGexp" : -0.186,
        "gal4RGsig" : 0.45723,
        "name" : "YBL079W",
        "COMMON" : "NUP170",
        "SUID" : 736,
        "gal4RGexp" : -0.032,
        "selected" : false,
        "gal80Rsig" : 2.9469E-9
      },
      "position" : {
        "x" : -487.98170244298626,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "734",
        "shared_name" : "YLR345W",
        "gal1RGsig" : 0.012373,
        "gal80Rexp" : 0.116,
        "gal1RGexp" : 0.108,
        "gal4RGsig" : 7.892E-5,
        "name" : "YLR345W",
        "COMMON" : "YLR345W",
        "SUID" : 734,
        "gal4RGexp" : 0.234,
        "selected" : false,
        "gal80Rsig" : 0.073789
      },
      "position" : {
        "x" : -587.9817024429863,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "730",
        "shared_name" : "YIL052C",
        "gal1RGsig" : 3.7855E-5,
        "gal80Rexp" : -0.025,
        "gal1RGexp" : -0.258,
        "gal4RGsig" : 3.4652E-7,
        "name" : "YIL052C",
        "COMMON" : "RPL34B",
        "SUID" : 730,
        "gal4RGexp" : -0.451,
        "selected" : false,
        "gal80Rsig" : 0.66627
      },
      "position" : {
        "x" : -787.9817024429863,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "728",
        "shared_name" : "YER056CA",
        "name" : "YER056CA",
        "SUID" : 728,
        "selected" : false
      },
      "position" : {
        "x" : 1012.0182975570137,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "726",
        "shared_name" : "YNL069C",
        "gal1RGsig" : 2.6481E-7,
        "gal80Rexp" : -0.124,
        "gal1RGexp" : -0.346,
        "gal4RGsig" : 5.1994E-5,
        "name" : "YNL069C",
        "COMMON" : "RPL16B",
        "SUID" : 726,
        "gal4RGexp" : -0.284,
        "selected" : false,
        "gal80Rsig" : 0.026888
      },
      "position" : {
        "x" : 912.0182975570137,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "723",
        "shared_name" : "YDL075W",
        "gal1RGsig" : 0.0041386,
        "gal80Rexp" : 0.056,
        "gal1RGexp" : -0.218,
        "gal4RGsig" : 1.5697E-6,
        "name" : "YDL075W",
        "COMMON" : "RPL31A",
        "SUID" : 723,
        "gal4RGexp" : -0.451,
        "selected" : false,
        "gal80Rsig" : 0.38208
      },
      "position" : {
        "x" : 612.0182975570137,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "721",
        "shared_name" : "YFR014C",
        "gal1RGsig" : 1.1443E-5,
        "gal80Rexp" : 0.047,
        "gal1RGexp" : 0.229,
        "gal4RGsig" : 8.1743E-6,
        "name" : "YFR014C",
        "COMMON" : "CMK1",
        "SUID" : 721,
        "gal4RGexp" : 0.304,
        "selected" : false,
        "gal80Rsig" : 0.64057
      },
      "position" : {
        "x" : 312.01829755701374,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "718",
        "shared_name" : "YGR136W",
        "gal1RGsig" : 2.4958E-4,
        "gal80Rexp" : -0.204,
        "gal1RGexp" : -0.167,
        "gal4RGsig" : 0.0042386,
        "name" : "YGR136W",
        "COMMON" : "YGR136W",
        "SUID" : 718,
        "gal4RGexp" : -0.163,
        "selected" : false,
        "gal80Rsig" : 0.0020376
      },
      "position" : {
        "x" : 112.01829755701374,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "716",
        "shared_name" : "YDL023C",
        "gal1RGsig" : 4.5602E-11,
        "gal80Rexp" : -0.406,
        "gal1RGexp" : -0.712,
        "gal4RGsig" : 1.8858E-5,
        "name" : "YDL023C",
        "COMMON" : "YDL023C",
        "SUID" : 716,
        "gal4RGexp" : 0.497,
        "selected" : false,
        "gal80Rsig" : 1.7119E-8
      },
      "position" : {
        "x" : 12.018297557013739,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "712",
        "shared_name" : "YBR170C",
        "gal1RGsig" : 0.0078298,
        "gal80Rexp" : 0.429,
        "gal1RGexp" : 0.128,
        "gal4RGsig" : 0.13454,
        "name" : "YBR170C",
        "COMMON" : "NPL4",
        "SUID" : 712,
        "gal4RGexp" : -0.134,
        "selected" : false,
        "gal80Rsig" : 0.0016184
      },
      "position" : {
        "x" : -87.98170244298626,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "709",
        "shared_name" : "YGR074W",
        "gal1RGsig" : 0.11939,
        "gal80Rexp" : 0.029,
        "gal1RGexp" : -0.074,
        "gal4RGsig" : 0.08221,
        "name" : "YGR074W",
        "COMMON" : "SMD1",
        "SUID" : 709,
        "gal4RGexp" : -0.133,
        "selected" : false,
        "gal80Rsig" : 0.80755
      },
      "position" : {
        "x" : -187.98170244298626,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "708",
        "shared_name" : "YGL202W",
        "gal1RGsig" : 4.2677E-7,
        "gal80Rexp" : -0.536,
        "gal1RGexp" : -0.305,
        "gal4RGsig" : 4.2373E-5,
        "name" : "YGL202W",
        "COMMON" : "ARO8",
        "SUID" : 708,
        "gal4RGexp" : -0.286,
        "selected" : false,
        "gal80Rsig" : 3.8938E-13
      },
      "position" : {
        "x" : -287.98170244298626,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "705",
        "shared_name" : "YLR197W",
        "gal1RGsig" : 0.70174,
        "gal80Rexp" : 0.49,
        "gal1RGexp" : 0.02,
        "gal4RGsig" : 1.0814E-5,
        "name" : "YLR197W",
        "COMMON" : "SIK1",
        "SUID" : 705,
        "gal4RGexp" : -0.521,
        "selected" : false,
        "gal80Rsig" : 3.3814E-8
      },
      "position" : {
        "x" : -487.98170244298626,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "703",
        "shared_name" : "YDL088C",
        "gal1RGsig" : 0.091906,
        "gal80Rexp" : 0.124,
        "gal1RGexp" : 0.069,
        "gal4RGsig" : 0.32752,
        "name" : "YDL088C",
        "COMMON" : "ASM4",
        "SUID" : 703,
        "gal4RGexp" : -0.074,
        "selected" : false,
        "gal80Rsig" : 0.081403
      },
      "position" : {
        "x" : -787.9817024429863,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "697",
        "shared_name" : "YOR215C",
        "gal1RGsig" : 7.0779E-4,
        "gal80Rexp" : 0.335,
        "gal1RGexp" : 0.151,
        "gal4RGsig" : 0.010881,
        "name" : "YOR215C",
        "COMMON" : "YOR215C",
        "SUID" : 697,
        "gal4RGexp" : 0.137,
        "selected" : false,
        "gal80Rsig" : 1.273E-4
      },
      "position" : {
        "x" : 812.0182975570137,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "695",
        "shared_name" : "YPR010C",
        "gal1RGsig" : 0.0032078,
        "gal80Rexp" : -0.359,
        "gal1RGexp" : -0.129,
        "gal4RGsig" : 5.8663E-5,
        "name" : "YPR010C",
        "COMMON" : "RPA135",
        "SUID" : 695,
        "gal4RGexp" : -0.394,
        "selected" : false,
        "gal80Rsig" : 0.0061199
      },
      "position" : {
        "x" : 612.0182975570137,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "693",
        "shared_name" : "YMR117C",
        "gal1RGsig" : 0.41398,
        "gal80Rexp" : -0.296,
        "gal1RGexp" : 0.093,
        "gal4RGsig" : 5.0622E-5,
        "name" : "YMR117C",
        "COMMON" : "SPC24",
        "SUID" : 693,
        "gal4RGexp" : 0.371,
        "selected" : false,
        "gal80Rsig" : 0.35411
      },
      "position" : {
        "x" : 412.01829755701374,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "691",
        "shared_name" : "YML114C",
        "gal1RGsig" : 4.5247E-4,
        "gal80Rexp" : 0.385,
        "gal1RGexp" : 0.226,
        "gal4RGsig" : 0.12134,
        "name" : "YML114C",
        "COMMON" : "YML114C",
        "SUID" : 691,
        "gal4RGexp" : -0.145,
        "selected" : false,
        "gal80Rsig" : 0.0058304
      },
      "position" : {
        "x" : 212.01829755701374,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "689",
        "shared_name" : "YNL036W",
        "gal1RGsig" : 4.2628E-11,
        "gal80Rexp" : 0.686,
        "gal1RGexp" : 0.998,
        "gal4RGsig" : 1.601E-8,
        "name" : "YNL036W",
        "COMMON" : "NCE103",
        "SUID" : 689,
        "gal4RGexp" : 0.506,
        "selected" : false,
        "gal80Rsig" : 3.3349E-7
      },
      "position" : {
        "x" : -87.98170244298626,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "687",
        "shared_name" : "YOR212W",
        "gal1RGsig" : 4.187E-5,
        "gal80Rexp" : -0.158,
        "gal1RGexp" : -0.189,
        "gal4RGsig" : 0.0010135,
        "name" : "YOR212W",
        "COMMON" : "STE4",
        "SUID" : 687,
        "gal4RGexp" : -0.256,
        "selected" : false,
        "gal80Rsig" : 0.023184
      },
      "position" : {
        "x" : -187.98170244298626,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "684",
        "shared_name" : "YDR070C",
        "gal1RGsig" : 4.6513E-11,
        "gal80Rexp" : -0.089,
        "gal1RGexp" : -0.915,
        "gal4RGsig" : 1.488E-4,
        "name" : "YDR070C",
        "COMMON" : "YDR070C",
        "SUID" : 684,
        "gal4RGexp" : 0.671,
        "selected" : false,
        "gal80Rsig" : 0.1936
      },
      "position" : {
        "x" : -387.98170244298626,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "677",
        "shared_name" : "YNL164C",
        "gal1RGsig" : 7.3947E-4,
        "gal80Rexp" : 1.345,
        "gal1RGexp" : 0.272,
        "gal4RGsig" : 3.8499E-5,
        "name" : "YNL164C",
        "COMMON" : "YNL164C",
        "SUID" : 677,
        "gal4RGexp" : -0.949,
        "selected" : false,
        "gal80Rsig" : 5.7872E-6
      },
      "position" : {
        "x" : -787.9817024429863,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "675",
        "shared_name" : "YGR046W",
        "gal1RGsig" : 0.0020954,
        "gal80Rexp" : 0.124,
        "gal1RGexp" : 0.158,
        "gal4RGsig" : 5.1497E-4,
        "name" : "YGR046W",
        "COMMON" : "YGR046W",
        "SUID" : 675,
        "gal4RGexp" : 0.177,
        "selected" : false,
        "gal80Rsig" : 0.10073
      },
      "position" : {
        "x" : 1012.0182975570137,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "673",
        "shared_name" : "YLR153C",
        "gal1RGsig" : 0.24703,
        "gal80Rexp" : -0.172,
        "gal1RGexp" : -0.042,
        "gal4RGsig" : 0.78003,
        "name" : "YLR153C",
        "COMMON" : "ACS2",
        "SUID" : 673,
        "gal4RGexp" : -0.014,
        "selected" : false,
        "gal80Rsig" : 0.011567
      },
      "position" : {
        "x" : 812.0182975570137,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "669",
        "shared_name" : "YIL070C",
        "gal1RGsig" : 0.68369,
        "gal80Rexp" : -0.339,
        "gal1RGexp" : 0.033,
        "gal4RGsig" : 0.0033116,
        "name" : "YIL070C",
        "COMMON" : "MAM33",
        "SUID" : 669,
        "gal4RGexp" : 0.146,
        "selected" : false,
        "gal80Rsig" : 9.0003E-6
      },
      "position" : {
        "x" : 512.0182975570137,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "667",
        "shared_name" : "YPR113W",
        "gal1RGsig" : 1.0456E-9,
        "gal80Rexp" : -0.89,
        "gal1RGexp" : -0.495,
        "gal4RGsig" : 0.54593,
        "name" : "YPR113W",
        "COMMON" : "PIS1",
        "SUID" : 667,
        "gal4RGexp" : 0.025,
        "selected" : false,
        "gal80Rsig" : 5.6202E-18
      },
      "position" : {
        "x" : -407.5331245621269,
        "y" : -1183.2444829501353
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "665",
        "shared_name" : "YER081W",
        "gal1RGsig" : 2.5284E-10,
        "gal80Rexp" : 0.109,
        "gal1RGexp" : -0.568,
        "gal4RGsig" : 3.0368E-5,
        "name" : "YER081W",
        "COMMON" : "SER3",
        "SUID" : 665,
        "gal4RGexp" : -0.423,
        "selected" : false,
        "gal80Rsig" : 0.094304
      },
      "position" : {
        "x" : 412.01829755701374,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "663",
        "shared_name" : "YGR088W",
        "gal1RGsig" : 1.6823E-10,
        "gal80Rexp" : -0.394,
        "gal1RGexp" : -0.91,
        "gal4RGsig" : 1.9828E-4,
        "name" : "YGR088W",
        "COMMON" : "CTT1",
        "SUID" : 663,
        "gal4RGexp" : 0.596,
        "selected" : false,
        "gal80Rsig" : 3.0726E-6
      },
      "position" : {
        "x" : 402.3339103499825,
        "y" : -1744.7379827059947
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "660",
        "shared_name" : "YDR395W",
        "gal1RGsig" : 0.021972,
        "gal80Rexp" : -0.214,
        "gal1RGexp" : -0.119,
        "gal4RGsig" : 0.5176,
        "name" : "YDR395W",
        "COMMON" : "SXM1",
        "SUID" : 660,
        "gal4RGexp" : 0.086,
        "selected" : false,
        "gal80Rsig" : 0.40913
      },
      "position" : {
        "x" : 312.01829755701374,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "658",
        "shared_name" : "YGR085C",
        "gal1RGsig" : 2.639E-4,
        "gal80Rexp" : -0.084,
        "gal1RGexp" : -0.188,
        "gal4RGsig" : 7.4028E-7,
        "name" : "YGR085C",
        "COMMON" : "RPL11B",
        "SUID" : 658,
        "gal4RGexp" : -0.425,
        "selected" : false,
        "gal80Rsig" : 0.1613
      },
      "position" : {
        "x" : 212.01829755701374,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "651",
        "shared_name" : "YER124C",
        "gal1RGsig" : 1.8529E-4,
        "gal80Rexp" : -0.022,
        "gal1RGexp" : 0.179,
        "gal4RGsig" : 0.014038,
        "name" : "YER124C",
        "COMMON" : "YER124C",
        "SUID" : 651,
        "gal4RGexp" : 0.126,
        "selected" : false,
        "gal80Rsig" : 0.76846
      },
      "position" : {
        "x" : 12.018297557013739,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "649",
        "shared_name" : "YMR005W",
        "gal1RGsig" : 5.0658E-5,
        "gal80Rexp" : 0.571,
        "gal1RGexp" : 0.218,
        "gal4RGsig" : 1.2336E-4,
        "name" : "YMR005W",
        "COMMON" : "MPT1",
        "SUID" : 649,
        "gal4RGexp" : -0.419,
        "selected" : false,
        "gal80Rsig" : 9.5685E-5
      },
      "position" : {
        "x" : -87.98170244298626,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "647",
        "shared_name" : "YDL030W",
        "gal1RGsig" : 2.7658E-4,
        "gal80Rexp" : 0.339,
        "gal1RGexp" : 0.244,
        "gal4RGsig" : 0.25629,
        "name" : "YDL030W",
        "COMMON" : "PRP9",
        "SUID" : 647,
        "gal4RGexp" : -0.119,
        "selected" : false,
        "gal80Rsig" : 0.011822
      },
      "position" : {
        "x" : -187.98170244298626,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "644",
        "shared_name" : "YER079W",
        "gal1RGsig" : 4.1949E-4,
        "gal80Rexp" : -0.046,
        "gal1RGexp" : -0.174,
        "gal4RGsig" : 4.6903E-5,
        "name" : "YER079W",
        "COMMON" : "YER079W",
        "SUID" : 644,
        "gal4RGexp" : -0.267,
        "selected" : false,
        "gal80Rsig" : 0.40867
      },
      "position" : {
        "x" : -287.98170244298626,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "641",
        "shared_name" : "YDL215C",
        "gal1RGsig" : 9.0717E-9,
        "gal80Rexp" : 0.0,
        "gal1RGexp" : 0.485,
        "gal4RGsig" : 0.21914,
        "name" : "YDL215C",
        "COMMON" : "GDH2",
        "SUID" : 641,
        "gal4RGexp" : 0.242,
        "selected" : false,
        "gal80Rsig" : 0.999999
      },
      "position" : {
        "x" : 987.2420982161934,
        "y" : -1945.1151189364634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "638",
        "shared_name" : "YIL045W",
        "gal1RGsig" : 0.056656,
        "gal80Rexp" : -0.134,
        "gal1RGexp" : -0.078,
        "gal4RGsig" : 8.8839E-7,
        "name" : "YIL045W",
        "COMMON" : "PIG2",
        "SUID" : 638,
        "gal4RGexp" : 0.478,
        "selected" : false,
        "gal80Rsig" : 0.072301
      },
      "position" : {
        "x" : -387.98170244298626,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "632",
        "shared_name" : "YPR041W",
        "gal1RGsig" : 0.11203,
        "gal80Rexp" : -0.177,
        "gal1RGexp" : -0.059,
        "gal4RGsig" : 0.0061997,
        "name" : "YPR041W",
        "COMMON" : "TIF5",
        "SUID" : 632,
        "gal4RGexp" : -0.243,
        "selected" : false,
        "gal80Rsig" : 0.011738
      },
      "position" : {
        "x" : -887.9817024429863,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "630",
        "shared_name" : "YOR120W",
        "gal1RGsig" : 9.0303E-5,
        "gal80Rexp" : 0.576,
        "gal1RGexp" : 0.194,
        "gal4RGsig" : 1.8298E-5,
        "name" : "YOR120W",
        "COMMON" : "GCY1",
        "SUID" : 630,
        "gal4RGexp" : -0.349,
        "selected" : true,
        "gal80Rsig" : 6.3927E-9
      },
      "position" : {
        "x" : -50.83375322423626,
        "y" : -1505.7339696444712
      },
      "selected" : true
    }, {
      "data" : {
        "id" : "623",
        "shared_name" : "YIL074C",
        "gal1RGsig" : 4.9389E-9,
        "gal80Rexp" : 0.393,
        "gal1RGexp" : -0.444,
        "gal4RGsig" : 2.6626E-5,
        "name" : "YIL074C",
        "COMMON" : "SER33",
        "SUID" : 623,
        "gal4RGexp" : -0.565,
        "selected" : false,
        "gal80Rsig" : 0.022682
      },
      "position" : {
        "x" : 612.0182975570137,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "621",
        "shared_name" : "YDR299W",
        "gal1RGsig" : 1.6082E-7,
        "gal80Rexp" : 0.883,
        "gal1RGexp" : 0.518,
        "gal4RGsig" : 0.20033,
        "name" : "YDR299W",
        "COMMON" : "BFR2",
        "SUID" : 621,
        "gal4RGexp" : -0.287,
        "selected" : false,
        "gal80Rsig" : 1.0236E-4
      },
      "position" : {
        "x" : -620.0017524918144,
        "y" : -818.181891397401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "619",
        "shared_name" : "YHR005C",
        "gal1RGsig" : 0.64417,
        "gal80Rexp" : 0.33,
        "gal1RGexp" : -0.02,
        "gal4RGsig" : 5.0285E-5,
        "name" : "YHR005C",
        "COMMON" : "GPA1",
        "SUID" : 619,
        "gal4RGexp" : -0.413,
        "selected" : false,
        "gal80Rsig" : 0.0031233
      },
      "position" : {
        "x" : 212.01829755701374,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "618",
        "shared_name" : "YLR452C",
        "gal1RGsig" : 2.4276E-7,
        "gal80Rexp" : -0.269,
        "gal1RGexp" : -0.507,
        "gal4RGsig" : 6.6966E-6,
        "name" : "YLR452C",
        "COMMON" : "SST2",
        "SUID" : 618,
        "gal4RGexp" : -0.393,
        "selected" : false,
        "gal80Rsig" : 0.014595
      },
      "position" : {
        "x" : 112.01829755701374,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "616",
        "shared_name" : "YMR255W",
        "gal1RGsig" : 2.2142E-4,
        "gal80Rexp" : 0.397,
        "gal1RGexp" : 0.211,
        "gal4RGsig" : 0.11742,
        "name" : "YMR255W",
        "COMMON" : "GFD1",
        "SUID" : 616,
        "gal4RGexp" : -0.159,
        "selected" : false,
        "gal80Rsig" : 0.0029074
      },
      "position" : {
        "x" : 12.018297557013739,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "615",
        "shared_name" : "YBR274W",
        "gal1RGsig" : 0.35655,
        "gal80Rexp" : -0.052,
        "gal1RGexp" : -0.045,
        "gal4RGsig" : 0.0049782,
        "name" : "YBR274W",
        "COMMON" : "CHK1",
        "SUID" : 615,
        "gal4RGexp" : 0.135,
        "selected" : false,
        "gal80Rsig" : 0.55148
      },
      "position" : {
        "x" : -87.98170244298626,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "613",
        "shared_name" : "YHR084W",
        "gal1RGsig" : 0.014623,
        "gal80Rexp" : 0.057,
        "gal1RGexp" : -0.109,
        "gal4RGsig" : 6.6062E-6,
        "name" : "YHR084W",
        "COMMON" : "STE12",
        "SUID" : 613,
        "gal4RGexp" : -0.541,
        "selected" : false,
        "gal80Rsig" : 0.65365
      },
      "position" : {
        "x" : -688.6396309097831,
        "y" : -1050.2271794833384
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "610",
        "shared_name" : "YBL050W",
        "gal1RGsig" : 0.11213,
        "gal80Rexp" : 0.106,
        "gal1RGexp" : -0.066,
        "gal4RGsig" : 0.48722,
        "name" : "YBL050W",
        "COMMON" : "SEC17",
        "SUID" : 610,
        "gal4RGexp" : -0.044,
        "selected" : false,
        "gal80Rsig" : 0.23706
      },
      "position" : {
        "x" : -587.9817024429863,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "608",
        "shared_name" : "YBL026W",
        "gal1RGsig" : 0.48423,
        "gal80Rexp" : -0.064,
        "gal1RGexp" : -0.032,
        "gal4RGsig" : 0.019199,
        "name" : "YBL026W",
        "COMMON" : "LSM2",
        "SUID" : 608,
        "gal4RGexp" : -0.158,
        "selected" : false,
        "gal80Rsig" : 0.59933
      },
      "position" : {
        "x" : -687.9817024429863,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "604",
        "shared_name" : "YJL194W",
        "gal1RGsig" : 0.83635,
        "gal80Rexp" : 0.525,
        "gal1RGexp" : 0.018,
        "gal4RGsig" : 4.5029E-5,
        "name" : "YJL194W",
        "COMMON" : "CDC6",
        "SUID" : 604,
        "gal4RGexp" : -0.661,
        "selected" : false,
        "gal80Rsig" : 0.050004
      },
      "position" : {
        "x" : -542.0729805191581,
        "y" : -919.7592229403698
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "602",
        "shared_name" : "YLR258W",
        "gal1RGsig" : 4.4171E-9,
        "gal80Rexp" : -0.487,
        "gal1RGexp" : -0.405,
        "gal4RGsig" : 1.8329E-6,
        "name" : "YLR258W",
        "COMMON" : "GSY2",
        "SUID" : 602,
        "gal4RGexp" : 0.4,
        "selected" : false,
        "gal80Rsig" : 5.8675E-12
      },
      "position" : {
        "x" : 912.0182975570137,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "600",
        "shared_name" : "YGL134W",
        "gal1RGsig" : 0.0020577,
        "gal80Rexp" : 0.839,
        "gal1RGexp" : 0.138,
        "gal4RGsig" : 3.6977E-7,
        "name" : "YGL134W",
        "COMMON" : "PCL10",
        "SUID" : 600,
        "gal4RGexp" : -0.548,
        "selected" : false,
        "gal80Rsig" : 3.7595E-7
      },
      "position" : {
        "x" : 612.0182975570137,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "598",
        "shared_name" : "YHR055C",
        "gal1RGsig" : 2.8813E-6,
        "gal80Rexp" : 0.802,
        "gal1RGexp" : -0.867,
        "gal4RGsig" : 0.026753,
        "name" : "YHR055C",
        "COMMON" : "CUP1B",
        "SUID" : 598,
        "gal4RGexp" : -0.416,
        "selected" : false,
        "gal80Rsig" : 1.9696E-12
      },
      "position" : {
        "x" : 644.95048749842,
        "y" : -2014.1965245761119
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "596",
        "shared_name" : "YHR053C",
        "gal1RGsig" : 1.6731E-4,
        "gal80Rexp" : 0.795,
        "gal1RGexp" : -0.656,
        "gal4RGsig" : 8.4638E-4,
        "name" : "YHR053C",
        "COMMON" : "CUP1A",
        "SUID" : 596,
        "gal4RGexp" : -0.75,
        "selected" : false,
        "gal80Rsig" : 1.5187E-10
      },
      "position" : {
        "x" : 665.5421012679512,
        "y" : -2141.6170415438855
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "594",
        "shared_name" : "YPR124W",
        "gal1RGsig" : 8.4218E-11,
        "gal80Rexp" : -0.462,
        "gal1RGexp" : 0.76,
        "gal4RGsig" : 2.4189E-8,
        "name" : "YPR124W",
        "COMMON" : "CTR1",
        "SUID" : 594,
        "gal4RGexp" : 0.469,
        "selected" : false,
        "gal80Rsig" : 8.3821E-6
      },
      "position" : {
        "x" : -382.7377144058769,
        "y" : -149.9284881009406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "592",
        "shared_name" : "YNL135C",
        "gal1RGsig" : 0.047943,
        "gal80Rexp" : -0.169,
        "gal1RGexp" : -0.071,
        "gal4RGsig" : 0.068027,
        "name" : "YNL135C",
        "COMMON" : "FPR1",
        "SUID" : 592,
        "gal4RGexp" : 0.08,
        "selected" : false,
        "gal80Rsig" : 0.0016167
      },
      "position" : {
        "x" : 212.01829755701374,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "591",
        "shared_name" : "YER052C",
        "gal1RGsig" : 4.7628E-9,
        "gal80Rexp" : 0.579,
        "gal1RGexp" : -0.47,
        "gal4RGsig" : 1.9577E-9,
        "name" : "YER052C",
        "COMMON" : "HOM3",
        "SUID" : 591,
        "gal4RGexp" : -1.321,
        "selected" : false,
        "gal80Rsig" : 1.3742E-5
      },
      "position" : {
        "x" : 12.018297557013739,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "588",
        "shared_name" : "YLR284C",
        "gal1RGsig" : 0.0052304,
        "gal80Rexp" : 0.716,
        "gal1RGexp" : 0.195,
        "gal4RGsig" : 0.21531,
        "name" : "YLR284C",
        "COMMON" : "ECI1",
        "SUID" : 588,
        "gal4RGexp" : -0.148,
        "selected" : false,
        "gal80Rsig" : 3.9241E-4
      },
      "position" : {
        "x" : -287.98170244298626,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "586",
        "shared_name" : "YHR198C",
        "gal1RGsig" : 0.20226,
        "gal80Rexp" : -0.379,
        "gal1RGexp" : -0.053,
        "gal4RGsig" : 1.9253E-7,
        "name" : "YHR198C",
        "COMMON" : "YHR198C",
        "SUID" : 586,
        "gal4RGexp" : 0.401,
        "selected" : false,
        "gal80Rsig" : 5.4324E-8
      },
      "position" : {
        "x" : -487.98170244298626,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "582",
        "shared_name" : "YPL240C",
        "gal1RGsig" : 1.8582E-5,
        "gal80Rexp" : -0.661,
        "gal1RGexp" : 0.222,
        "gal4RGsig" : 0.0024157,
        "name" : "YPL240C",
        "COMMON" : "HSP82",
        "SUID" : 582,
        "gal4RGexp" : -0.201,
        "selected" : false,
        "gal80Rsig" : 6.7688E-11
      },
      "position" : {
        "x" : -887.9817024429863,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "579",
        "shared_name" : "YPR102C",
        "gal1RGsig" : 3.7183E-4,
        "gal80Rexp" : -0.058,
        "gal1RGexp" : -0.177,
        "gal4RGsig" : 1.7424E-6,
        "name" : "YPR102C",
        "COMMON" : "RPL11A",
        "SUID" : 579,
        "gal4RGexp" : -0.38,
        "selected" : false,
        "gal80Rsig" : 0.26052
      },
      "position" : {
        "x" : 912.0182975570137,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "578",
        "shared_name" : "YLR075W",
        "gal1RGsig" : 1.7255E-4,
        "gal80Rexp" : -0.002,
        "gal1RGexp" : -0.169,
        "gal4RGsig" : 4.2857E-4,
        "name" : "YLR075W",
        "COMMON" : "RPL10",
        "SUID" : 578,
        "gal4RGexp" : -0.2,
        "selected" : false,
        "gal80Rsig" : 0.9794
      },
      "position" : {
        "x" : 812.0182975570137,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "575",
        "shared_name" : "YKL161C",
        "gal1RGsig" : 7.5801E-4,
        "gal80Rexp" : 0.202,
        "gal1RGexp" : -0.198,
        "gal4RGsig" : 0.022048,
        "name" : "YKL161C",
        "COMMON" : "YKL161C",
        "SUID" : 575,
        "gal4RGexp" : -0.319,
        "selected" : false,
        "gal80Rsig" : 0.18731
      },
      "position" : {
        "x" : 512.0182975570137,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "572",
        "shared_name" : "YAR007C",
        "gal1RGsig" : 0.0081844,
        "gal80Rexp" : -0.302,
        "gal1RGexp" : 0.2,
        "gal4RGsig" : 0.91522,
        "name" : "YAR007C",
        "COMMON" : "RFA1",
        "SUID" : 572,
        "gal4RGexp" : -0.007,
        "selected" : false,
        "gal80Rsig" : 0.0060792
      },
      "position" : {
        "x" : -654.8473945816581,
        "y" : -149.9284881009406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "559",
        "shared_name" : "YIL160C",
        "gal1RGsig" : 1.071E-6,
        "gal80Rexp" : 0.92,
        "gal1RGexp" : 1.044,
        "gal4RGsig" : 3.103E-8,
        "name" : "YIL160C",
        "COMMON" : "POT1",
        "SUID" : 559,
        "gal4RGexp" : 0.674,
        "selected" : false,
        "gal80Rsig" : 6.0801E-7
      },
      "position" : {
        "x" : 212.01829755701374,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "555",
        "shared_name" : "YDL078C",
        "gal1RGsig" : 4.0255E-5,
        "gal80Rexp" : -0.08,
        "gal1RGexp" : 0.217,
        "gal4RGsig" : 0.038943,
        "name" : "YDL078C",
        "COMMON" : "MDH3",
        "SUID" : 555,
        "gal4RGexp" : 0.102,
        "selected" : false,
        "gal80Rsig" : 0.16505
      },
      "position" : {
        "x" : 112.01829755701374,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "553",
        "shared_name" : "YDR142C",
        "gal1RGsig" : 0.016464,
        "gal80Rexp" : -0.069,
        "gal1RGexp" : -0.101,
        "gal4RGsig" : 0.16704,
        "name" : "YDR142C",
        "COMMON" : "PEX7",
        "SUID" : 553,
        "gal4RGexp" : 0.112,
        "selected" : false,
        "gal80Rsig" : 0.401
      },
      "position" : {
        "x" : 12.018297557013739,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "549",
        "shared_name" : "YDR244W",
        "gal1RGsig" : 2.7503E-6,
        "gal80Rexp" : 0.483,
        "gal1RGexp" : 0.369,
        "gal4RGsig" : 0.73489,
        "name" : "YDR244W",
        "COMMON" : "PEX5",
        "SUID" : 549,
        "gal4RGexp" : -0.021,
        "selected" : false,
        "gal80Rsig" : 4.3149E-4
      },
      "position" : {
        "x" : -87.98170244298626,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "546",
        "shared_name" : "YLR432W",
        "gal1RGsig" : 6.6826E-5,
        "gal80Rexp" : -0.301,
        "gal1RGexp" : -0.197,
        "gal4RGsig" : 0.36112,
        "name" : "YLR432W",
        "COMMON" : "YLR432W",
        "SUID" : 546,
        "gal4RGexp" : -0.054,
        "selected" : false,
        "gal80Rsig" : 4.8207E-5
      },
      "position" : {
        "x" : -187.98170244298626,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "545",
        "shared_name" : "YDR167W",
        "gal1RGsig" : 2.1837E-4,
        "gal80Rexp" : 0.355,
        "gal1RGexp" : 0.246,
        "gal4RGsig" : 0.0039024,
        "name" : "YDR167W",
        "COMMON" : "TAF25",
        "SUID" : 545,
        "gal4RGexp" : -0.219,
        "selected" : false,
        "gal80Rsig" : 0.01484
      },
      "position" : {
        "x" : -287.98170244298626,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "543",
        "shared_name" : "YLR175W",
        "gal1RGsig" : 0.47804,
        "gal80Rexp" : 0.498,
        "gal1RGexp" : 0.038,
        "gal4RGsig" : 5.549E-5,
        "name" : "YLR175W",
        "COMMON" : "CBF5",
        "SUID" : 543,
        "gal4RGexp" : -0.597,
        "selected" : false,
        "gal80Rsig" : 1.4113E-7
      },
      "position" : {
        "x" : -387.98170244298626,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "541",
        "shared_name" : "YNL117W",
        "gal1RGsig" : 1.92E-11,
        "gal80Rexp" : 0.941,
        "gal1RGexp" : 0.973,
        "gal4RGsig" : 9.0335E-5,
        "name" : "YNL117W",
        "COMMON" : "MLS1",
        "SUID" : 541,
        "gal4RGexp" : 0.452,
        "selected" : false,
        "gal80Rsig" : 1.2597E-5
      },
      "position" : {
        "x" : -22.011197682244074,
        "y" : -1087.5675725497447
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "539",
        "shared_name" : "YOR089C",
        "gal1RGsig" : 1.1748E-4,
        "gal80Rexp" : 0.378,
        "gal1RGexp" : 0.193,
        "gal4RGsig" : 0.32501,
        "name" : "YOR089C",
        "COMMON" : "VPS21",
        "SUID" : 539,
        "gal4RGexp" : -0.042,
        "selected" : false,
        "gal80Rsig" : 8.2229E-6
      },
      "position" : {
        "x" : -487.98170244298626,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "537",
        "shared_name" : "YPR167C",
        "gal1RGsig" : 0.17278,
        "gal80Rexp" : 0.708,
        "gal1RGexp" : -0.066,
        "gal4RGsig" : 1.3067E-6,
        "name" : "YPR167C",
        "COMMON" : "MET16",
        "SUID" : 537,
        "gal4RGexp" : -1.034,
        "selected" : false,
        "gal80Rsig" : 5.3086E-4
      },
      "position" : {
        "x" : -860.5284553726738,
        "y" : -1939.7592229403697
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "535",
        "shared_name" : "YNL214W",
        "gal1RGsig" : 0.166,
        "gal80Rexp" : 0.199,
        "gal1RGexp" : 0.122,
        "gal4RGsig" : 0.64313,
        "name" : "YNL214W",
        "COMMON" : "PEX17",
        "SUID" : 535,
        "gal4RGexp" : 0.041,
        "selected" : false,
        "gal80Rsig" : 0.11918
      },
      "position" : {
        "x" : -587.9817024429863,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "533",
        "shared_name" : "YBR135W",
        "gal1RGsig" : 0.0084321,
        "gal80Rexp" : 0.057,
        "gal1RGexp" : 0.108,
        "gal4RGsig" : 0.6558,
        "name" : "YBR135W",
        "COMMON" : "CKS1",
        "SUID" : 533,
        "gal4RGexp" : -0.018,
        "selected" : false,
        "gal80Rsig" : 0.34065
      },
      "position" : {
        "x" : -687.9817024429863,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "531",
        "shared_name" : "YML007W",
        "gal1RGsig" : 9.2417E-8,
        "gal80Rexp" : 0.331,
        "gal1RGexp" : 0.359,
        "gal4RGsig" : 0.42858,
        "name" : "YML007W",
        "COMMON" : "YAP1",
        "SUID" : 531,
        "gal4RGexp" : -0.039,
        "selected" : false,
        "gal80Rsig" : 0.0024709
      },
      "position" : {
        "x" : -787.9817024429863,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "530",
        "shared_name" : "YER110C",
        "gal1RGsig" : 0.26052,
        "gal80Rexp" : 0.43,
        "gal1RGexp" : 0.05,
        "gal4RGsig" : 2.9645E-4,
        "name" : "YER110C",
        "COMMON" : "KAP123",
        "SUID" : 530,
        "gal4RGexp" : -0.233,
        "selected" : false,
        "gal80Rsig" : 3.6344E-7
      },
      "position" : {
        "x" : -887.9817024429863,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "528",
        "shared_name" : "YGL153W",
        "gal1RGsig" : 1.2953E-4,
        "gal80Rexp" : 0.627,
        "gal1RGexp" : 0.242,
        "gal4RGsig" : 0.077941,
        "name" : "YGL153W",
        "COMMON" : "PEX14",
        "SUID" : 528,
        "gal4RGexp" : -0.132,
        "selected" : false,
        "gal80Rsig" : 0.0023167
      },
      "position" : {
        "x" : 962.328432444709,
        "y" : -149.9284881009406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "527",
        "shared_name" : "YLR191W",
        "gal1RGsig" : 7.6925E-4,
        "gal80Rexp" : 0.222,
        "gal1RGexp" : 0.178,
        "gal4RGsig" : 0.58305,
        "name" : "YLR191W",
        "COMMON" : "PEX13",
        "SUID" : 527,
        "gal4RGexp" : -0.056,
        "selected" : false,
        "gal80Rsig" : 0.097987
      },
      "position" : {
        "x" : 862.328432444709,
        "y" : -149.9284881009406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "523",
        "shared_name" : "YOL149W",
        "gal1RGsig" : 9.0847E-5,
        "gal80Rexp" : 0.254,
        "gal1RGexp" : 0.228,
        "gal4RGsig" : 0.0015911,
        "name" : "YOL149W",
        "COMMON" : "DCP1",
        "SUID" : 523,
        "gal4RGexp" : -0.248,
        "selected" : false,
        "gal80Rsig" : 0.059331
      },
      "position" : {
        "x" : 762.328432444709,
        "y" : -149.9284881009406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "521",
        "shared_name" : "YMR044W",
        "gal1RGsig" : 4.4526E-5,
        "gal80Rexp" : 0.357,
        "gal1RGexp" : 0.255,
        "gal4RGsig" : 0.15055,
        "name" : "YMR044W",
        "COMMON" : "YMR044W",
        "SUID" : 521,
        "gal4RGexp" : -0.093,
        "selected" : false,
        "gal80Rsig" : 8.8242E-4
      },
      "position" : {
        "x" : 662.328432444709,
        "y" : -149.9284881009406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "519",
        "shared_name" : "YOR362C",
        "gal1RGsig" : 0.31634,
        "gal80Rexp" : 0.225,
        "gal1RGexp" : 0.036,
        "gal4RGsig" : 0.2984,
        "name" : "YOR362C",
        "COMMON" : "PRE10",
        "SUID" : 519,
        "gal4RGexp" : -0.043,
        "selected" : false,
        "gal80Rsig" : 0.0013356
      },
      "position" : {
        "x" : 562.328432444709,
        "y" : -149.9284881009406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "517",
        "shared_name" : "YER102W",
        "gal1RGsig" : 3.2712E-5,
        "gal80Rexp" : -0.135,
        "gal1RGexp" : -0.249,
        "gal4RGsig" : 3.6609E-6,
        "name" : "YER102W",
        "COMMON" : "RPS8B",
        "SUID" : 517,
        "gal4RGexp" : -0.364,
        "selected" : false,
        "gal80Rsig" : 0.017595
      },
      "position" : {
        "x" : 462.32843244470905,
        "y" : -149.9284881009406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "515",
        "shared_name" : "YOL059W",
        "gal1RGsig" : 3.3837E-8,
        "gal80Rexp" : -0.591,
        "gal1RGexp" : -0.499,
        "gal4RGsig" : 2.3802E-5,
        "name" : "YOL059W",
        "COMMON" : "GPD2",
        "SUID" : 515,
        "gal4RGexp" : -0.29,
        "selected" : false,
        "gal80Rsig" : 1.5256E-9
      },
      "position" : {
        "x" : 362.32843244470905,
        "y" : -149.9284881009406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "513",
        "shared_name" : "YBR190W",
        "gal1RGsig" : 4.514E-5,
        "gal80Rexp" : 0.07,
        "gal1RGexp" : -0.209,
        "gal4RGsig" : 3.8823E-4,
        "name" : "YBR190W",
        "COMMON" : "YBR190W",
        "SUID" : 513,
        "gal4RGexp" : -0.3,
        "selected" : false,
        "gal80Rsig" : 0.66515
      },
      "position" : {
        "x" : 262.32843244470905,
        "y" : -149.9284881009406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "507",
        "shared_name" : "YER103W",
        "gal1RGsig" : 1.2362E-4,
        "gal80Rexp" : -0.826,
        "gal1RGexp" : -0.405,
        "gal4RGsig" : 0.013281,
        "name" : "YER103W",
        "COMMON" : "SSA4",
        "SUID" : 507,
        "gal4RGexp" : 0.176,
        "selected" : false,
        "gal80Rsig" : 8.3702E-13
      },
      "position" : {
        "x" : 814.1582206527169,
        "y" : -1968.7570371188365
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "505",
        "shared_name" : "YPR110C",
        "gal1RGsig" : 0.0019607,
        "gal80Rexp" : -0.026,
        "gal1RGexp" : -0.12,
        "gal4RGsig" : 1.2743E-5,
        "name" : "YPR110C",
        "COMMON" : "RPC40",
        "SUID" : 505,
        "gal4RGexp" : -0.339,
        "selected" : false,
        "gal80Rsig" : 0.70564
      },
      "position" : {
        "x" : 162.32843244470905,
        "y" : -149.9284881009406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "504",
        "shared_name" : "YNL113W",
        "gal1RGsig" : 1.0276E-5,
        "gal80Rexp" : 0.789,
        "gal1RGexp" : 0.304,
        "gal4RGsig" : 4.8347E-7,
        "name" : "YNL113W",
        "COMMON" : "RPC19",
        "SUID" : 504,
        "gal4RGexp" : -0.979,
        "selected" : false,
        "gal80Rsig" : 0.0028937
      },
      "position" : {
        "x" : 62.32843244470905,
        "y" : -149.9284881009406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "502",
        "shared_name" : "YDR354W",
        "gal1RGsig" : 0.0090277,
        "gal80Rexp" : -0.253,
        "gal1RGexp" : -0.122,
        "gal4RGsig" : 0.0028196,
        "name" : "YDR354W",
        "COMMON" : "TRP4",
        "SUID" : 502,
        "gal4RGexp" : -0.202,
        "selected" : false,
        "gal80Rsig" : 0.0012089
      },
      "position" : {
        "x" : -279.3707538803642,
        "y" : -2068.051489786073
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "500",
        "shared_name" : "YER090W",
        "gal1RGsig" : 0.079619,
        "gal80Rexp" : 0.231,
        "gal1RGexp" : -0.067,
        "gal4RGsig" : 1.9673E-5,
        "name" : "YER090W",
        "COMMON" : "TRP2",
        "SUID" : 500,
        "gal4RGexp" : -0.38,
        "selected" : false,
        "gal80Rsig" : 0.0015768
      },
      "position" : {
        "x" : -37.67156755529095,
        "y" : -149.9284881009406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "499",
        "shared_name" : "YKL211C",
        "gal1RGsig" : 1.6589E-4,
        "gal80Rexp" : 0.358,
        "gal1RGexp" : -0.183,
        "gal4RGsig" : 4.2736E-7,
        "name" : "YKL211C",
        "COMMON" : "TRP3",
        "SUID" : 499,
        "gal4RGexp" : -0.6,
        "selected" : false,
        "gal80Rsig" : 1.5264E-4
      },
      "position" : {
        "x" : -137.67156755529095,
        "y" : -149.9284881009406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "496",
        "shared_name" : "YDR146C",
        "gal1RGsig" : 0.0018541,
        "gal80Rexp" : -0.027,
        "gal1RGexp" : -0.19,
        "gal4RGsig" : 0.1065,
        "name" : "YDR146C",
        "COMMON" : "SWI5",
        "SUID" : 496,
        "gal4RGexp" : 0.102,
        "selected" : false,
        "gal80Rsig" : 0.76249
      },
      "position" : {
        "x" : -283.4818340500419,
        "y" : -1266.399420694276
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "494",
        "shared_name" : "YER111C",
        "gal1RGsig" : 5.6134E-4,
        "gal80Rexp" : 0.16,
        "gal1RGexp" : 0.195,
        "gal4RGsig" : 0.33211,
        "name" : "YER111C",
        "COMMON" : "SWI4",
        "SUID" : 494,
        "gal4RGexp" : -0.105,
        "selected" : false,
        "gal80Rsig" : 0.15558
      },
      "position" : {
        "x" : -401.41961443029095,
        "y" : -971.798346475526
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "492",
        "shared_name" : "YOR039W",
        "gal1RGsig" : 0.87354,
        "gal80Rexp" : -0.006,
        "gal1RGexp" : -0.006,
        "gal4RGsig" : 0.20402,
        "name" : "YOR039W",
        "COMMON" : "CKB2",
        "SUID" : 492,
        "gal4RGexp" : -0.058,
        "selected" : false,
        "gal80Rsig" : 0.92034
      },
      "position" : {
        "x" : -587.9817024429863,
        "y" : 1210.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "490",
        "shared_name" : "YML024W",
        "gal1RGsig" : 6.9725E-11,
        "gal80Rexp" : -0.864,
        "gal1RGexp" : -0.551,
        "gal4RGsig" : 1.5459E-6,
        "name" : "YML024W",
        "COMMON" : "RPS17A",
        "SUID" : 490,
        "gal4RGexp" : -0.454,
        "selected" : false,
        "gal80Rsig" : 1.3115E-12
      },
      "position" : {
        "x" : -371.00084459386517,
        "y" : -1853.6693944491587
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "488",
        "shared_name" : "YIL113W",
        "gal1RGsig" : 0.002113,
        "gal80Rexp" : -0.137,
        "gal1RGexp" : -0.236,
        "gal4RGsig" : 0.002831,
        "name" : "YIL113W",
        "COMMON" : "YIL113W",
        "SUID" : 488,
        "gal4RGexp" : 0.211,
        "selected" : false,
        "gal80Rsig" : 0.23739
      },
      "position" : {
        "x" : -687.9817024429863,
        "y" : 1210.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "487",
        "shared_name" : "YLL019C",
        "gal1RGsig" : 1.3809E-5,
        "gal80Rexp" : 0.295,
        "gal1RGexp" : 0.258,
        "gal4RGsig" : 6.085E-5,
        "name" : "YLL019C",
        "COMMON" : "KNS1",
        "SUID" : 487,
        "gal4RGexp" : 0.215,
        "selected" : false,
        "gal80Rsig" : 9.3514E-5
      },
      "position" : {
        "x" : -787.9817024429863,
        "y" : 1210.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "485",
        "shared_name" : "YDR009W",
        "gal1RGsig" : 0.01257,
        "gal80Rexp" : 0.162,
        "gal1RGexp" : -0.111,
        "gal4RGsig" : 6.9834E-8,
        "name" : "YDR009W",
        "COMMON" : "GAL3",
        "SUID" : 485,
        "gal4RGexp" : -1.004,
        "selected" : false,
        "gal80Rsig" : 0.16498
      },
      "position" : {
        "x" : -220.41421281896282,
        "y" : -1399.344275430604
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "483",
        "shared_name" : "YML051W",
        "gal1RGsig" : 0.080275,
        "gal80Rexp" : -1.167,
        "gal1RGexp" : -0.07,
        "gal4RGsig" : 4.3863E-8,
        "name" : "YML051W",
        "COMMON" : "GAL80",
        "SUID" : 483,
        "gal4RGexp" : -0.606,
        "selected" : true,
        "gal80Rsig" : 8.1952E-17
      },
      "position" : {
        "x" : 178.9628471175606,
        "y" : -1494.6999425448619
      },
      "selected" : true
    }, {
      "data" : {
        "id" : "480",
        "shared_name" : "YHR071W",
        "gal1RGsig" : 5.0065E-11,
        "gal80Rexp" : -0.499,
        "gal1RGexp" : -0.614,
        "gal4RGsig" : 4.2811E-6,
        "name" : "YHR071W",
        "COMMON" : "PCL5",
        "SUID" : 480,
        "gal4RGexp" : -0.67,
        "selected" : false,
        "gal80Rsig" : 6.8054E-8
      },
      "position" : {
        "x" : -887.9817024429863,
        "y" : 1210.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "479",
        "shared_name" : "YPL031C",
        "gal1RGsig" : 0.012838,
        "gal80Rexp" : -0.139,
        "gal1RGexp" : -0.106,
        "gal4RGsig" : 0.0056375,
        "name" : "YPL031C",
        "COMMON" : "PHO85",
        "SUID" : 479,
        "gal4RGexp" : 0.125,
        "selected" : false,
        "gal80Rsig" : 0.019984
      },
      "position" : {
        "x" : 1012.0182975570137,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "477",
        "shared_name" : "YML123C",
        "gal1RGsig" : 0.0015163,
        "gal80Rexp" : 0.692,
        "gal1RGexp" : 0.283,
        "gal4RGsig" : 0.019412,
        "name" : "YML123C",
        "COMMON" : "PHO84",
        "SUID" : 477,
        "gal4RGexp" : -0.114,
        "selected" : false,
        "gal80Rsig" : 6.9606E-7
      },
      "position" : {
        "x" : -887.9817024429863,
        "y" : -1656.6761643447123
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "475",
        "shared_name" : "YER145C",
        "gal1RGsig" : 6.6247E-9,
        "gal80Rexp" : 0.868,
        "gal1RGexp" : 0.647,
        "gal4RGsig" : 6.332E-5,
        "name" : "YER145C",
        "COMMON" : "FTR1",
        "SUID" : 475,
        "gal4RGexp" : -0.78,
        "selected" : false,
        "gal80Rsig" : 5.9656E-7
      },
      "position" : {
        "x" : 912.0182975570137,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "474",
        "shared_name" : "YMR058W",
        "gal1RGsig" : 3.6962E-8,
        "gal80Rexp" : 0.64,
        "gal1RGexp" : 0.449,
        "gal4RGsig" : 4.7738E-4,
        "name" : "YMR058W",
        "COMMON" : "FET3",
        "SUID" : 474,
        "gal4RGexp" : -0.293,
        "selected" : false,
        "gal80Rsig" : 1.6005E-8
      },
      "position" : {
        "x" : 812.0182975570137,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "472",
        "shared_name" : "YJL190C",
        "gal1RGsig" : 1.0479E-5,
        "gal80Rexp" : -0.184,
        "gal1RGexp" : -0.444,
        "gal4RGsig" : 1.8121E-6,
        "name" : "YJL190C",
        "COMMON" : "RPS22A",
        "SUID" : 472,
        "gal4RGexp" : -0.443,
        "selected" : false,
        "gal80Rsig" : 0.0020712
      },
      "position" : {
        "x" : 712.0182975570137,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "471",
        "shared_name" : "YML074C",
        "gal1RGsig" : 0.02495,
        "gal80Rexp" : 0.389,
        "gal1RGexp" : 0.118,
        "gal4RGsig" : 5.2953E-5,
        "name" : "YML074C",
        "COMMON" : "NPI46",
        "SUID" : 471,
        "gal4RGexp" : -0.38,
        "selected" : false,
        "gal80Rsig" : 3.3233E-5
      },
      "position" : {
        "x" : 612.0182975570137,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "469",
        "shared_name" : "YOR355W",
        "gal1RGsig" : 1.6613E-4,
        "gal80Rexp" : 0.43,
        "gal1RGexp" : -0.176,
        "gal4RGsig" : 0.45777,
        "name" : "YOR355W",
        "COMMON" : "GDS1",
        "SUID" : 469,
        "gal4RGexp" : -0.044,
        "selected" : false,
        "gal80Rsig" : 0.0062666
      },
      "position" : {
        "x" : 512.0182975570137,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "467",
        "shared_name" : "YFL038C",
        "gal1RGsig" : 0.056883,
        "gal80Rexp" : 0.12,
        "gal1RGexp" : 0.075,
        "gal4RGsig" : 0.44841,
        "name" : "YFL038C",
        "COMMON" : "YPT1",
        "SUID" : 467,
        "gal4RGexp" : -0.033,
        "selected" : false,
        "gal80Rsig" : 0.073548
      },
      "position" : {
        "x" : 412.01829755701374,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "465",
        "shared_name" : "YIL162W",
        "gal1RGsig" : 4.1442E-7,
        "gal80Rexp" : -1.131,
        "gal1RGexp" : -0.318,
        "gal4RGsig" : 1.7862E-9,
        "name" : "YIL162W",
        "COMMON" : "SUC2",
        "SUID" : 465,
        "gal4RGexp" : 0.688,
        "selected" : false,
        "gal80Rsig" : 1.7403E-20
      },
      "position" : {
        "x" : -125.7735573013847,
        "y" : -1621.917601541444
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "461",
        "shared_name" : "YBR050C",
        "gal1RGsig" : 6.914E-8,
        "gal80Rexp" : 0.122,
        "gal1RGexp" : 0.432,
        "gal4RGsig" : 2.9767E-8,
        "name" : "YBR050C",
        "COMMON" : "REG2",
        "SUID" : 461,
        "gal4RGexp" : 0.679,
        "selected" : false,
        "gal80Rsig" : 0.28411
      },
      "position" : {
        "x" : 312.01829755701374,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "459",
        "shared_name" : "YMR311C",
        "gal1RGsig" : 0.0015202,
        "gal80Rexp" : 0.349,
        "gal1RGexp" : 0.214,
        "gal4RGsig" : 0.64469,
        "name" : "YMR311C",
        "COMMON" : "GLC8",
        "SUID" : 459,
        "gal4RGexp" : 0.021,
        "selected" : false,
        "gal80Rsig" : 6.5604E-6
      },
      "position" : {
        "x" : 212.01829755701374,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "457",
        "shared_name" : "YOR315W",
        "gal1RGsig" : 0.13594,
        "gal80Rexp" : -0.063,
        "gal1RGexp" : 0.066,
        "gal4RGsig" : 4.7159E-6,
        "name" : "YOR315W",
        "COMMON" : "YOR315W",
        "SUID" : 457,
        "gal4RGexp" : -0.462,
        "selected" : false,
        "gal80Rsig" : 0.50938
      },
      "position" : {
        "x" : 112.01829755701374,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "455",
        "shared_name" : "YOR178C",
        "gal1RGsig" : 0.0010176,
        "gal80Rexp" : -0.187,
        "gal1RGexp" : -0.137,
        "gal4RGsig" : 1.5883E-6,
        "name" : "YOR178C",
        "COMMON" : "GAC1",
        "SUID" : 455,
        "gal4RGexp" : 0.462,
        "selected" : false,
        "gal80Rsig" : 0.0036854
      },
      "position" : {
        "x" : 12.018297557013739,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "453",
        "shared_name" : "YER133W",
        "gal1RGsig" : 0.20733,
        "gal80Rexp" : -0.051,
        "gal1RGexp" : 0.051,
        "gal4RGsig" : 0.063996,
        "name" : "YER133W",
        "COMMON" : "GLC7",
        "SUID" : 453,
        "gal4RGexp" : -0.085,
        "selected" : false,
        "gal80Rsig" : 0.36616
      },
      "position" : {
        "x" : -87.98170244298626,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "451",
        "shared_name" : "YOR290C",
        "gal1RGsig" : 0.0030289,
        "gal80Rexp" : -0.577,
        "gal1RGexp" : -0.119,
        "gal4RGsig" : 0.029664,
        "name" : "YOR290C",
        "COMMON" : "SNF2",
        "SUID" : 451,
        "gal4RGexp" : -0.101,
        "selected" : false,
        "gal80Rsig" : 3.6284E-13
      },
      "position" : {
        "x" : -187.98170244298626,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "450",
        "shared_name" : "YFR037C",
        "gal1RGsig" : 1.5078E-6,
        "gal80Rexp" : 0.35,
        "gal1RGexp" : 0.297,
        "gal4RGsig" : 0.013849,
        "name" : "YFR037C",
        "COMMON" : "RSC8",
        "SUID" : 450,
        "gal4RGexp" : -0.226,
        "selected" : false,
        "gal80Rsig" : 0.0035541
      },
      "position" : {
        "x" : -287.98170244298626,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "448",
        "shared_name" : "YFR034C",
        "gal1RGsig" : 0.099513,
        "gal80Rexp" : 0.348,
        "gal1RGexp" : 0.121,
        "gal4RGsig" : 6.9671E-4,
        "name" : "YFR034C",
        "COMMON" : "PHO4",
        "SUID" : 448,
        "gal4RGexp" : -0.336,
        "selected" : false,
        "gal80Rsig" : 0.020802
      },
      "position" : {
        "x" : -775.67500078283,
        "y" : -1699.0434331454478
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "446",
        "shared_name" : "YAL040C",
        "gal1RGsig" : 0.66515,
        "gal80Rexp" : 0.303,
        "gal1RGexp" : -0.027,
        "gal4RGsig" : 0.0017369,
        "name" : "YAL040C",
        "COMMON" : "CLN3",
        "SUID" : 446,
        "gal4RGexp" : -0.206,
        "selected" : false,
        "gal80Rsig" : 0.0010074
      },
      "position" : {
        "x" : -344.2675071915214,
        "y" : -1128.0855779208384
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "444",
        "shared_name" : "YPL222W",
        "gal1RGsig" : 6.9654E-7,
        "gal80Rexp" : 0.514,
        "gal1RGexp" : 0.344,
        "gal4RGsig" : 1.3673E-4,
        "name" : "YPL222W",
        "COMMON" : "YPL222W",
        "SUID" : 444,
        "gal4RGexp" : 0.284,
        "selected" : false,
        "gal80Rsig" : 4.6216E-5
      },
      "position" : {
        "x" : -387.98170244298626,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "443",
        "shared_name" : "YGR048W",
        "gal1RGsig" : 0.696,
        "gal80Rexp" : 0.364,
        "gal1RGexp" : 0.017,
        "gal4RGsig" : 0.028001,
        "name" : "YGR048W",
        "COMMON" : "UFD1",
        "SUID" : 443,
        "gal4RGexp" : -0.155,
        "selected" : false,
        "gal80Rsig" : 0.0043651
      },
      "position" : {
        "x" : -487.98170244298626,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "441",
        "shared_name" : "YMR291W",
        "gal1RGsig" : 7.9783E-8,
        "gal80Rexp" : -0.397,
        "gal1RGexp" : -0.363,
        "gal4RGsig" : 0.012617,
        "name" : "YMR291W",
        "COMMON" : "YMR291W",
        "SUID" : 441,
        "gal4RGexp" : 0.256,
        "selected" : false,
        "gal80Rsig" : 5.3037E-9
      },
      "position" : {
        "x" : -587.9817024429863,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "439",
        "shared_name" : "YGR009C",
        "gal1RGsig" : 2.9579E-5,
        "gal80Rexp" : 0.302,
        "gal1RGexp" : 0.236,
        "gal4RGsig" : 0.017416,
        "name" : "YGR009C",
        "COMMON" : "SEC9",
        "SUID" : 439,
        "gal4RGexp" : -0.185,
        "selected" : false,
        "gal80Rsig" : 4.4067E-4
      },
      "position" : {
        "x" : -687.9817024429863,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "438",
        "shared_name" : "YMR183C",
        "gal1RGsig" : 2.1741E-11,
        "gal80Rexp" : -0.825,
        "gal1RGexp" : -0.822,
        "gal4RGsig" : 0.0021146,
        "name" : "YMR183C",
        "COMMON" : "SSO2",
        "SUID" : 438,
        "gal4RGexp" : 0.256,
        "selected" : false,
        "gal80Rsig" : 1.0306E-16
      },
      "position" : {
        "x" : -787.9817024429863,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "436",
        "shared_name" : "YDR100W",
        "gal1RGsig" : 0.86711,
        "gal80Rexp" : -0.415,
        "gal1RGexp" : -0.007,
        "gal4RGsig" : 1.3164E-5,
        "name" : "YDR100W",
        "COMMON" : "YDR100W",
        "SUID" : 436,
        "gal4RGexp" : 0.275,
        "selected" : false,
        "gal80Rsig" : 5.7948E-10
      },
      "position" : {
        "x" : -887.9817024429863,
        "y" : 1110.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "435",
        "shared_name" : "YGL161C",
        "gal1RGsig" : 0.053915,
        "gal80Rexp" : -0.164,
        "gal1RGexp" : -0.07,
        "gal4RGsig" : 8.9167E-4,
        "name" : "YGL161C",
        "COMMON" : "YGL161C",
        "SUID" : 435,
        "gal4RGexp" : 0.172,
        "selected" : false,
        "gal80Rsig" : 0.0065587
      },
      "position" : {
        "x" : 1012.0182975570137,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "433",
        "shared_name" : "YPL131W",
        "gal1RGsig" : 1.0523E-5,
        "gal80Rexp" : -0.246,
        "gal1RGexp" : -0.228,
        "gal4RGsig" : 0.0049489,
        "name" : "YPL131W",
        "COMMON" : "RPL5",
        "SUID" : 433,
        "gal4RGexp" : -0.149,
        "selected" : false,
        "gal80Rsig" : 1.4759E-4
      },
      "position" : {
        "x" : 912.0182975570137,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "432",
        "shared_name" : "YDL063C",
        "gal1RGsig" : 0.055312,
        "gal80Rexp" : 0.971,
        "gal1RGexp" : 0.093,
        "gal4RGsig" : 0.0023991,
        "name" : "YDL063C",
        "COMMON" : "YDL063C",
        "SUID" : 432,
        "gal4RGexp" : -0.755,
        "selected" : false,
        "gal80Rsig" : 0.0013668
      },
      "position" : {
        "x" : 812.0182975570137,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "430",
        "shared_name" : "YNL167C",
        "gal1RGsig" : 0.024036,
        "gal80Rexp" : -0.18,
        "gal1RGexp" : 0.095,
        "gal4RGsig" : 0.079913,
        "name" : "YNL167C",
        "COMMON" : "SKO1",
        "SUID" : 430,
        "gal4RGexp" : 0.1,
        "selected" : false,
        "gal80Rsig" : 0.015501
      },
      "position" : {
        "x" : -82.54348527990032,
        "y" : -1763.7874440707408
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "428",
        "shared_name" : "YHR115C",
        "gal1RGsig" : 0.143,
        "gal80Rexp" : 0.138,
        "gal1RGexp" : 0.056,
        "gal4RGsig" : 0.33678,
        "name" : "YHR115C",
        "COMMON" : "YHR115C",
        "SUID" : 428,
        "gal4RGexp" : 0.044,
        "selected" : false,
        "gal80Rsig" : 0.079261
      },
      "position" : {
        "x" : 712.0182975570137,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "427",
        "shared_name" : "YEL041W",
        "gal1RGsig" : 4.7824E-4,
        "gal80Rexp" : -0.265,
        "gal1RGexp" : 0.211,
        "gal4RGsig" : 3.204E-7,
        "name" : "YEL041W",
        "COMMON" : "YEL041W",
        "SUID" : 427,
        "gal4RGexp" : 0.393,
        "selected" : false,
        "gal80Rsig" : 0.035715
      },
      "position" : {
        "x" : 612.0182975570137,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "425",
        "shared_name" : "YDL113C",
        "gal1RGsig" : 9.9404E-5,
        "gal80Rexp" : 0.304,
        "gal1RGexp" : 0.189,
        "gal4RGsig" : 0.8523,
        "name" : "YDL113C",
        "COMMON" : "YDL113C",
        "SUID" : 425,
        "gal4RGexp" : 0.011,
        "selected" : false,
        "gal80Rsig" : 0.0063436
      },
      "position" : {
        "x" : 512.0182975570137,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "424",
        "shared_name" : "YJL036W",
        "gal1RGsig" : 1.3457E-4,
        "gal80Rexp" : 0.376,
        "gal1RGexp" : 0.195,
        "gal4RGsig" : 0.36812,
        "name" : "YJL036W",
        "COMMON" : "SNX4",
        "SUID" : 424,
        "gal4RGexp" : -0.051,
        "selected" : false,
        "gal80Rsig" : 9.7735E-4
      },
      "position" : {
        "x" : 412.01829755701374,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "422",
        "shared_name" : "YBR109C",
        "gal1RGsig" : 0.024989,
        "gal80Rexp" : -0.163,
        "gal1RGexp" : -0.089,
        "gal4RGsig" : 0.13694,
        "name" : "YBR109C",
        "COMMON" : "CMD1",
        "SUID" : 422,
        "gal4RGexp" : 0.074,
        "selected" : false,
        "gal80Rsig" : 0.0092082
      },
      "position" : {
        "x" : 312.01829755701374,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "421",
        "shared_name" : "YOL016C",
        "gal1RGsig" : 6.846E-7,
        "gal80Rexp" : -0.138,
        "gal1RGexp" : -0.365,
        "gal4RGsig" : 0.024371,
        "name" : "YOL016C",
        "COMMON" : "CMK2",
        "SUID" : 421,
        "gal4RGexp" : -0.108,
        "selected" : false,
        "gal80Rsig" : 0.027128
      },
      "position" : {
        "x" : 212.01829755701374,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "418",
        "shared_name" : "YKL001C",
        "gal1RGsig" : 0.0020562,
        "gal80Rexp" : 0.683,
        "gal1RGexp" : -0.152,
        "gal4RGsig" : 2.7503E-6,
        "name" : "YKL001C",
        "COMMON" : "MET14",
        "SUID" : 418,
        "gal4RGexp" : -0.474,
        "selected" : false,
        "gal80Rsig" : 2.7054E-7
      },
      "position" : {
        "x" : 112.01829755701374,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "417",
        "shared_name" : "YNL311C",
        "gal1RGsig" : 0.3444,
        "gal80Rexp" : -0.169,
        "gal1RGexp" : -0.055,
        "gal4RGsig" : 0.0089606,
        "name" : "YNL311C",
        "COMMON" : "YNL311C",
        "SUID" : 417,
        "gal4RGexp" : -0.388,
        "selected" : false,
        "gal80Rsig" : 0.12031
      },
      "position" : {
        "x" : 12.018297557013739,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "415",
        "shared_name" : "YLR319C",
        "gal1RGsig" : 0.18355,
        "gal80Rexp" : 0.21,
        "gal1RGexp" : 0.071,
        "gal4RGsig" : 0.0039398,
        "name" : "YLR319C",
        "COMMON" : "BUD6",
        "SUID" : 415,
        "gal4RGexp" : -0.201,
        "selected" : false,
        "gal80Rsig" : 0.072655
      },
      "position" : {
        "x" : -87.98170244298626,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "413",
        "shared_name" : "YPR062W",
        "gal1RGsig" : 0.066907,
        "gal80Rexp" : -0.071,
        "gal1RGexp" : -0.07,
        "gal4RGsig" : 0.006637,
        "name" : "YPR062W",
        "COMMON" : "FCY1",
        "SUID" : 413,
        "gal4RGexp" : -0.145,
        "selected" : false,
        "gal80Rsig" : 0.26496
      },
      "position" : {
        "x" : -187.98170244298626,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "410",
        "shared_name" : "YPL111W",
        "gal1RGsig" : 7.2553E-4,
        "gal80Rexp" : 0.957,
        "gal1RGexp" : 0.186,
        "gal4RGsig" : 1.8582E-4,
        "name" : "YPL111W",
        "COMMON" : "CAR1",
        "SUID" : 410,
        "gal4RGexp" : -0.26,
        "selected" : false,
        "gal80Rsig" : 5.2368E-11
      },
      "position" : {
        "x" : -565.6898628433769,
        "y" : -87.89555963414372
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "408",
        "shared_name" : "YDL236W",
        "gal1RGsig" : 2.9509E-4,
        "gal80Rexp" : -0.258,
        "gal1RGexp" : -0.223,
        "gal4RGsig" : 5.3874E-5,
        "name" : "YDL236W",
        "COMMON" : "PHO13",
        "SUID" : 408,
        "gal4RGexp" : -0.311,
        "selected" : false,
        "gal80Rsig" : 8.095E-4
      },
      "position" : {
        "x" : -287.98170244298626,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "407",
        "shared_name" : "YNL189W",
        "gal1RGsig" : 0.045195,
        "gal80Rexp" : -0.573,
        "gal1RGexp" : 0.082,
        "gal4RGsig" : 0.79134,
        "name" : "YNL189W",
        "COMMON" : "SRP1",
        "SUID" : 407,
        "gal4RGexp" : 0.014,
        "selected" : false,
        "gal80Rsig" : 1.4096E-8
      },
      "position" : {
        "x" : -387.98170244298626,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "405",
        "shared_name" : "YBL069W",
        "gal1RGsig" : 1.9402E-6,
        "gal80Rexp" : -0.026,
        "gal1RGexp" : -0.272,
        "gal4RGsig" : 7.0045E-6,
        "name" : "YBL069W",
        "COMMON" : "AST1",
        "SUID" : 405,
        "gal4RGexp" : -0.487,
        "selected" : false,
        "gal80Rsig" : 0.87354
      },
      "position" : {
        "x" : -487.98170244298626,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "402",
        "shared_name" : "YGL073W",
        "gal1RGsig" : 0.034847,
        "gal80Rexp" : 0.543,
        "gal1RGexp" : 0.104,
        "gal4RGsig" : 0.42981,
        "name" : "YGL073W",
        "COMMON" : "HSF1",
        "SUID" : 402,
        "gal4RGexp" : -0.084,
        "selected" : false,
        "gal80Rsig" : 6.2254E-4
      },
      "position" : {
        "x" : 748.9032157699044,
        "y" : -2062.7366857089246
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "401",
        "shared_name" : "YBR072W",
        "gal1RGsig" : 1.3135E-6,
        "gal80Rexp" : -0.447,
        "gal1RGexp" : -1.232,
        "gal4RGsig" : 2.3868E-5,
        "name" : "YBR072W",
        "COMMON" : "HSP26",
        "SUID" : 401,
        "gal4RGexp" : 0.895,
        "selected" : false,
        "gal80Rsig" : 3.3493E-11
      },
      "position" : {
        "x" : 840.6821159163887,
        "y" : -2131.130392984315
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "399",
        "shared_name" : "YLR321C",
        "gal1RGsig" : 2.6832E-5,
        "gal80Rexp" : 0.427,
        "gal1RGexp" : 0.252,
        "gal4RGsig" : 5.2576E-4,
        "name" : "YLR321C",
        "COMMON" : "SFH1",
        "SUID" : 399,
        "gal4RGexp" : -0.352,
        "selected" : false,
        "gal80Rsig" : 0.0047054
      },
      "position" : {
        "x" : -587.9817024429863,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "396",
        "shared_name" : "YPR048W",
        "gal1RGsig" : 0.12893,
        "gal80Rexp" : 0.289,
        "gal1RGexp" : 0.113,
        "gal4RGsig" : 0.54556,
        "name" : "YPR048W",
        "COMMON" : "TAH18",
        "SUID" : 396,
        "gal4RGexp" : -0.191,
        "selected" : false,
        "gal80Rsig" : 0.063048
      },
      "position" : {
        "x" : -687.9817024429863,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "392",
        "shared_name" : "YNL199C",
        "gal1RGsig" : 0.005054,
        "gal80Rexp" : 0.433,
        "gal1RGexp" : 0.121,
        "gal4RGsig" : 0.0077746,
        "name" : "YNL199C",
        "COMMON" : "GCR2",
        "SUID" : 392,
        "gal4RGexp" : -0.162,
        "selected" : false,
        "gal80Rsig" : 5.6535E-5
      },
      "position" : {
        "x" : -787.9817024429863,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "388",
        "shared_name" : "YPL075W",
        "gal1RGsig" : 2.4947E-7,
        "gal80Rexp" : -0.53,
        "gal1RGexp" : -0.373,
        "gal4RGsig" : 0.046834,
        "name" : "YPL075W",
        "COMMON" : "GCR1",
        "SUID" : 388,
        "gal4RGexp" : -0.207,
        "selected" : false,
        "gal80Rsig" : 5.2661E-6
      },
      "position" : {
        "x" : -526.9221321304863,
        "y" : -1753.5814046420298
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "386",
        "shared_name" : "YHR179W",
        "gal1RGsig" : 2.6358E-8,
        "gal80Rexp" : -0.671,
        "gal1RGexp" : -0.565,
        "gal4RGsig" : 0.098356,
        "name" : "YHR179W",
        "COMMON" : "OYE2",
        "SUID" : 386,
        "gal4RGexp" : 0.078,
        "selected" : false,
        "gal80Rsig" : 3.6995E-11
      },
      "position" : {
        "x" : -887.9817024429863,
        "y" : 1010.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "384",
        "shared_name" : "YCL040W",
        "gal1RGsig" : 0.0093643,
        "gal80Rexp" : -0.221,
        "gal1RGexp" : -0.146,
        "gal4RGsig" : 1.0508E-6,
        "name" : "YCL040W",
        "COMMON" : "GLK1",
        "SUID" : 384,
        "gal4RGexp" : 0.542,
        "selected" : false,
        "gal80Rsig" : 2.0566E-4
      },
      "position" : {
        "x" : 1012.0182975570137,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "382",
        "shared_name" : "YFL039C",
        "gal1RGsig" : 3.2175E-4,
        "gal80Rexp" : -0.527,
        "gal1RGexp" : -0.16,
        "gal4RGsig" : 1.31E-4,
        "name" : "YFL039C",
        "COMMON" : "ACT1",
        "SUID" : 382,
        "gal4RGexp" : 0.192,
        "selected" : false,
        "gal80Rsig" : 6.0582E-12
      },
      "position" : {
        "x" : 912.0182975570137,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "380",
        "shared_name" : "YDL130W",
        "gal1RGsig" : 1.0483E-5,
        "gal80Rexp" : -0.24,
        "gal1RGexp" : -0.3,
        "gal4RGsig" : 0.01128,
        "name" : "YDL130W",
        "COMMON" : "RPP1B",
        "SUID" : 380,
        "gal4RGexp" : -0.123,
        "selected" : false,
        "gal80Rsig" : 2.1405E-5
      },
      "position" : {
        "x" : 812.0182975570137,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "379",
        "shared_name" : "YDR382W",
        "gal1RGsig" : 1.427E-5,
        "gal80Rexp" : -0.314,
        "gal1RGexp" : -0.218,
        "gal4RGsig" : 0.18479,
        "name" : "YDR382W",
        "COMMON" : "RPP2B",
        "SUID" : 379,
        "gal4RGexp" : -0.058,
        "selected" : false,
        "gal80Rsig" : 1.4245E-7
      },
      "position" : {
        "x" : 712.0182975570137,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "377",
        "shared_name" : "YJR066W",
        "gal1RGsig" : 0.47775,
        "gal80Rexp" : 0.111,
        "gal1RGexp" : -0.028,
        "gal4RGsig" : 2.5298E-5,
        "name" : "YJR066W",
        "COMMON" : "TOR1",
        "SUID" : 377,
        "gal4RGexp" : 0.326,
        "selected" : false,
        "gal80Rsig" : 0.1951
      },
      "position" : {
        "x" : 612.0182975570137,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "shared_name" : "?",
        "name" : "?",
        "SUID" : 375,
        "selected" : true
      },
      "position" : {
        "x" : -72.09686052404095,
        "y" : -1585.0952977694712
      },
      "selected" : true
    }, {
      "data" : {
        "id" : "373",
        "shared_name" : "YKL204W",
        "gal1RGsig" : 6.4944E-6,
        "gal80Rexp" : 0.16,
        "gal1RGexp" : 0.253,
        "gal4RGsig" : 0.9794,
        "name" : "YKL204W",
        "COMMON" : "YKL204W",
        "SUID" : 373,
        "gal4RGexp" : -0.002,
        "selected" : false,
        "gal80Rsig" : 0.091109
      },
      "position" : {
        "x" : 512.0182975570137,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "372",
        "shared_name" : "YNL154C",
        "gal1RGsig" : 0.76333,
        "gal80Rexp" : -0.438,
        "gal1RGexp" : -0.013,
        "gal4RGsig" : 0.21924,
        "name" : "YNL154C",
        "COMMON" : "YCK2",
        "SUID" : 372,
        "gal4RGexp" : -0.066,
        "selected" : false,
        "gal80Rsig" : 2.3558E-7
      },
      "position" : {
        "x" : 412.01829755701374,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "370",
        "shared_name" : "YNL047C",
        "gal1RGsig" : 0.0026155,
        "gal80Rexp" : 0.029,
        "gal1RGexp" : 0.14,
        "gal4RGsig" : 0.19124,
        "name" : "YNL047C",
        "COMMON" : "YNL047C",
        "SUID" : 370,
        "gal4RGexp" : -0.078,
        "selected" : false,
        "gal80Rsig" : 0.7773
      },
      "position" : {
        "x" : 312.01829755701374,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "368",
        "shared_name" : "YNL116W",
        "gal1RGsig" : 2.6759E-4,
        "gal80Rexp" : 0.358,
        "gal1RGexp" : 0.165,
        "gal4RGsig" : 0.63152,
        "name" : "YNL116W",
        "COMMON" : "YNL116W",
        "SUID" : 368,
        "gal4RGexp" : 0.027,
        "selected" : false,
        "gal80Rsig" : 2.7658E-4
      },
      "position" : {
        "x" : 212.01829755701374,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "367",
        "shared_name" : "YHR135C",
        "gal1RGsig" : 0.037285,
        "gal80Rexp" : 0.119,
        "gal1RGexp" : 0.082,
        "gal4RGsig" : 0.23999,
        "name" : "YHR135C",
        "COMMON" : "YCK1",
        "SUID" : 367,
        "gal4RGexp" : -0.049,
        "selected" : false,
        "gal80Rsig" : 0.037227
      },
      "position" : {
        "x" : 112.01829755701374,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "shared_name" : "YML064C",
        "gal1RGsig" : 0.37089,
        "gal80Rexp" : -0.0,
        "gal1RGexp" : -0.218,
        "gal4RGsig" : 0.45319,
        "name" : "YML064C",
        "COMMON" : "TEM1",
        "SUID" : 365,
        "gal4RGexp" : -0.069,
        "selected" : false,
        "gal80Rsig" : 0.999999
      },
      "position" : {
        "x" : 12.018297557013739,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "363",
        "shared_name" : "YKL074C",
        "gal1RGsig" : 0.96433,
        "gal80Rexp" : 0.608,
        "gal1RGexp" : 0.002,
        "gal4RGsig" : 2.8457E-4,
        "name" : "YKL074C",
        "COMMON" : "MUD2",
        "SUID" : 363,
        "gal4RGexp" : -0.294,
        "selected" : false,
        "gal80Rsig" : 3.4465E-4
      },
      "position" : {
        "x" : -87.98170244298626,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "361",
        "shared_name" : "YLR340W",
        "gal1RGsig" : 4.9964E-6,
        "gal80Rexp" : -0.361,
        "gal1RGexp" : -0.259,
        "gal4RGsig" : 0.0063648,
        "name" : "YLR340W",
        "COMMON" : "RPP0",
        "SUID" : 361,
        "gal4RGexp" : -0.148,
        "selected" : false,
        "gal80Rsig" : 2.0593E-7
      },
      "position" : {
        "x" : -187.98170244298626,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "360",
        "shared_name" : "YDL081C",
        "gal1RGsig" : 1.705E-5,
        "gal80Rexp" : -0.278,
        "gal1RGexp" : -0.429,
        "gal4RGsig" : 0.048133,
        "name" : "YDL081C",
        "COMMON" : "RPP1A",
        "SUID" : 360,
        "gal4RGexp" : -0.094,
        "selected" : false,
        "gal80Rsig" : 5.9631E-6
      },
      "position" : {
        "x" : -287.98170244298626,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "357",
        "shared_name" : "YGL166W",
        "gal1RGsig" : 0.33486,
        "gal80Rexp" : 0.147,
        "gal1RGexp" : -0.073,
        "gal4RGsig" : 0.0012181,
        "name" : "YGL166W",
        "COMMON" : "CUP2",
        "SUID" : 357,
        "gal4RGexp" : 0.243,
        "selected" : false,
        "gal80Rsig" : 0.032147
      },
      "position" : {
        "x" : 566.8456901351387,
        "y" : -2092.2117223300183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "356",
        "shared_name" : "YLL028W",
        "gal1RGsig" : 1.7163E-4,
        "gal80Rexp" : -0.24,
        "gal1RGexp" : -0.189,
        "gal4RGsig" : 0.27319,
        "name" : "YLL028W",
        "COMMON" : "TPO1",
        "SUID" : 356,
        "gal4RGexp" : -0.101,
        "selected" : false,
        "gal80Rsig" : 0.0047822
      },
      "position" : {
        "x" : -387.98170244298626,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "354",
        "shared_name" : "YDR174W",
        "gal1RGsig" : 5.1646E-8,
        "gal80Rexp" : -0.356,
        "gal1RGexp" : -0.314,
        "gal4RGsig" : 0.10372,
        "name" : "YDR174W",
        "COMMON" : "HMO1",
        "SUID" : 354,
        "gal4RGexp" : -0.083,
        "selected" : false,
        "gal80Rsig" : 3.4721E-8
      },
      "position" : {
        "x" : -487.98170244298626,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "353",
        "shared_name" : "YDR335W",
        "gal1RGsig" : 0.8595,
        "gal80Rexp" : 0.272,
        "gal1RGexp" : 0.028,
        "gal4RGsig" : 0.071598,
        "name" : "YDR335W",
        "COMMON" : "MSN5",
        "SUID" : 353,
        "gal4RGexp" : 0.189,
        "selected" : false,
        "gal80Rsig" : 0.2334
      },
      "position" : {
        "x" : -587.9817024429863,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "351",
        "shared_name" : "YLR214W",
        "gal1RGsig" : 4.6835E-9,
        "gal80Rexp" : 0.282,
        "gal1RGexp" : 0.518,
        "gal4RGsig" : 0.0018109,
        "name" : "YLR214W",
        "COMMON" : "FRE1",
        "SUID" : 351,
        "gal4RGexp" : -0.279,
        "selected" : false,
        "gal80Rsig" : 0.039051
      },
      "position" : {
        "x" : -237.67156755529095,
        "y" : 10.519906674450027
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "350",
        "shared_name" : "YMR021C",
        "gal1RGsig" : 0.6115,
        "gal80Rexp" : 0.066,
        "gal1RGexp" : 0.022,
        "gal4RGsig" : 0.59236,
        "name" : "YMR021C",
        "COMMON" : "MAC1",
        "SUID" : 350,
        "gal4RGexp" : -0.032,
        "selected" : false,
        "gal80Rsig" : 0.54119
      },
      "position" : {
        "x" : -312.7580238541191,
        "y" : -66.8951629056281
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "348",
        "shared_name" : "YLR377C",
        "gal1RGsig" : 2.1938E-10,
        "gal80Rexp" : 0.371,
        "gal1RGexp" : 0.873,
        "gal4RGsig" : 5.8901E-11,
        "name" : "YLR377C",
        "COMMON" : "FBP1",
        "SUID" : 348,
        "gal4RGexp" : 1.067,
        "selected" : false,
        "gal80Rsig" : 0.0037868
      },
      "position" : {
        "x" : -128.07618486486126,
        "y" : -1296.403571084901
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "345",
        "shared_name" : "YER065C",
        "gal1RGsig" : 1.8931E-10,
        "gal80Rexp" : 1.147,
        "gal1RGexp" : 0.65,
        "gal4RGsig" : 4.8501E-9,
        "name" : "YER065C",
        "COMMON" : "ICL1",
        "SUID" : 345,
        "gal4RGexp" : 0.591,
        "selected" : false,
        "gal80Rsig" : 3.4625E-8
      },
      "position" : {
        "x" : -95.4234596451347,
        "y" : -1025.0329045809947
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "344",
        "shared_name" : "YJL089W",
        "gal1RGsig" : 0.72688,
        "gal80Rexp" : 0.442,
        "gal1RGexp" : 0.037,
        "gal4RGsig" : 0.55601,
        "name" : "YJL089W",
        "COMMON" : "SIP4",
        "SUID" : 344,
        "gal4RGexp" : 0.169,
        "selected" : false,
        "gal80Rsig" : 0.033306
      },
      "position" : {
        "x" : -135.12901079259564,
        "y" : -1142.4903935946666
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "342",
        "shared_name" : "YHR030C",
        "gal1RGsig" : 1.349E-4,
        "gal80Rexp" : 0.21,
        "gal1RGexp" : -0.227,
        "gal4RGsig" : 2.7258E-4,
        "name" : "YHR030C",
        "COMMON" : "SLT2",
        "SUID" : 342,
        "gal4RGexp" : -0.24,
        "selected" : false,
        "gal80Rsig" : 0.0033506
      },
      "position" : {
        "x" : -687.9817024429863,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "341",
        "shared_name" : "YPL089C",
        "gal1RGsig" : 0.14513,
        "gal80Rexp" : 0.209,
        "gal1RGexp" : -0.06,
        "gal4RGsig" : 0.47601,
        "name" : "YPL089C",
        "COMMON" : "RLM1",
        "SUID" : 341,
        "gal4RGexp" : -0.037,
        "selected" : false,
        "gal80Rsig" : 0.0026491
      },
      "position" : {
        "x" : -787.9817024429863,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "339",
        "shared_name" : "YGL208W",
        "gal1RGsig" : 1.7995E-6,
        "gal80Rexp" : 0.139,
        "gal1RGexp" : 0.354,
        "gal4RGsig" : 1.1069E-6,
        "name" : "YGL208W",
        "COMMON" : "SIP2",
        "SUID" : 339,
        "gal4RGexp" : 0.406,
        "selected" : false,
        "gal80Rsig" : 0.097498
      },
      "position" : {
        "x" : -887.9817024429863,
        "y" : 910.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "338",
        "shared_name" : "YGL115W",
        "gal1RGsig" : 0.0058541,
        "gal80Rexp" : -0.221,
        "gal1RGexp" : -0.111,
        "gal4RGsig" : 0.011234,
        "name" : "YGL115W",
        "COMMON" : "SNF4",
        "SUID" : 338,
        "gal4RGexp" : 0.112,
        "selected" : false,
        "gal80Rsig" : 0.0027535
      },
      "position" : {
        "x" : 1012.0182975570137,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "336",
        "shared_name" : "YLR310C",
        "gal1RGsig" : 0.67137,
        "gal80Rexp" : -0.071,
        "gal1RGexp" : 0.015,
        "gal4RGsig" : 0.41028,
        "name" : "YLR310C",
        "COMMON" : "CDC25",
        "SUID" : 336,
        "gal4RGexp" : -0.037,
        "selected" : false,
        "gal80Rsig" : 0.25519
      },
      "position" : {
        "x" : 912.0182975570137,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "335",
        "shared_name" : "YNL098C",
        "gal1RGsig" : 0.20515,
        "gal80Rexp" : 0.293,
        "gal1RGexp" : 0.05,
        "gal4RGsig" : 0.23242,
        "name" : "YNL098C",
        "COMMON" : "RAS2",
        "SUID" : 335,
        "gal4RGexp" : 0.062,
        "selected" : false,
        "gal80Rsig" : 1.0426E-4
      },
      "position" : {
        "x" : 812.0182975570137,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "333",
        "shared_name" : "YGR019W",
        "gal1RGsig" : 0.0086582,
        "gal80Rexp" : -0.258,
        "gal1RGexp" : -0.163,
        "gal4RGsig" : 0.0011998,
        "name" : "YGR019W",
        "COMMON" : "UGA1",
        "SUID" : 333,
        "gal4RGexp" : 0.234,
        "selected" : false,
        "gal80Rsig" : 6.2171E-5
      },
      "position" : {
        "x" : 1117.6497520247872,
        "y" : -2044.1891850985728
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "331",
        "shared_name" : "YPR035W",
        "gal1RGsig" : 2.3885E-5,
        "gal80Rexp" : -0.172,
        "gal1RGexp" : -0.197,
        "gal4RGsig" : 2.9298E-9,
        "name" : "YPR035W",
        "COMMON" : "GLN1",
        "SUID" : 331,
        "gal4RGexp" : -1.06,
        "selected" : false,
        "gal80Rsig" : 0.036009
      },
      "position" : {
        "x" : 940.6821159163887,
        "y" : -2141.6170415438855
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "330",
        "shared_name" : "YER040W",
        "gal1RGsig" : 0.38375,
        "gal80Rexp" : 0.537,
        "gal1RGexp" : 0.098,
        "gal4RGsig" : 0.010321,
        "name" : "YER040W",
        "COMMON" : "GLN3",
        "SUID" : 330,
        "gal4RGexp" : -0.513,
        "selected" : false,
        "gal80Rsig" : 0.0018683
      },
      "position" : {
        "x" : 1007.9319175521309,
        "y" : -2053.2102880038465
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "328",
        "shared_name" : "YGL008C",
        "gal1RGsig" : 1.0007E-5,
        "gal80Rexp" : -0.573,
        "gal1RGexp" : -0.352,
        "gal4RGsig" : 7.1366E-4,
        "name" : "YGL008C",
        "COMMON" : "PMA1",
        "SUID" : 328,
        "gal4RGexp" : -0.282,
        "selected" : false,
        "gal80Rsig" : 1.2622E-6
      },
      "position" : {
        "x" : -395.2218300064628,
        "y" : -911.305670694276
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "326",
        "shared_name" : "YOR036W",
        "gal1RGsig" : 0.092135,
        "gal80Rexp" : 0.491,
        "gal1RGexp" : 0.071,
        "gal4RGsig" : 0.43055,
        "name" : "YOR036W",
        "COMMON" : "PEP12",
        "SUID" : 326,
        "gal4RGexp" : 0.037,
        "selected" : false,
        "gal80Rsig" : 1.6313E-6
      },
      "position" : {
        "x" : 712.0182975570137,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "325",
        "shared_name" : "YDR323C",
        "gal1RGsig" : 0.10243,
        "gal80Rexp" : 0.052,
        "gal1RGexp" : 0.164,
        "gal4RGsig" : 0.999999,
        "name" : "YDR323C",
        "COMMON" : "PEP7",
        "SUID" : 325,
        "gal4RGexp" : 0.0,
        "selected" : false,
        "gal80Rsig" : 0.69287
      },
      "position" : {
        "x" : 612.0182975570137,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "323",
        "shared_name" : "YBL005W",
        "gal1RGsig" : 0.64313,
        "gal80Rexp" : 0.0,
        "gal1RGexp" : -0.0,
        "gal4RGsig" : 0.999999,
        "name" : "YBL005W",
        "COMMON" : "PDR3",
        "SUID" : 323,
        "gal4RGexp" : 0.0,
        "selected" : false,
        "gal80Rsig" : 0.999999
      },
      "position" : {
        "x" : -754.8473945816581,
        "y" : -43.03272851842107
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "317",
        "shared_name" : "YBR160W",
        "gal1RGsig" : 0.7432,
        "gal80Rexp" : -0.405,
        "gal1RGexp" : -0.016,
        "gal4RGsig" : 0.32105,
        "name" : "YBR160W",
        "COMMON" : "CDC28",
        "SUID" : 317,
        "gal4RGexp" : -0.087,
        "selected" : false,
        "gal80Rsig" : 0.026081
      },
      "position" : {
        "x" : -516.7637764175956,
        "y" : -989.171393350526
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "316",
        "shared_name" : "YKL101W",
        "gal1RGsig" : 0.96433,
        "gal80Rexp" : 0.439,
        "gal1RGexp" : -0.01,
        "gal4RGsig" : 1.6928E-9,
        "name" : "YKL101W",
        "COMMON" : "HSL1",
        "SUID" : 316,
        "gal4RGexp" : 0.78,
        "selected" : false,
        "gal80Rsig" : 0.0030233
      },
      "position" : {
        "x" : 512.0182975570137,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "314",
        "shared_name" : "YOL156W",
        "gal1RGsig" : 8.1828E-6,
        "gal80Rexp" : 0.105,
        "gal1RGexp" : 0.298,
        "gal4RGsig" : 5.1939E-5,
        "name" : "YOL156W",
        "COMMON" : "HXT11",
        "SUID" : 314,
        "gal4RGexp" : 0.462,
        "selected" : false,
        "gal80Rsig" : 0.28091
      },
      "position" : {
        "x" : -781.1157661636894,
        "y" : -149.9284881009406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "312",
        "shared_name" : "YJL219W",
        "gal1RGsig" : 5.6008E-6,
        "gal80Rexp" : -0.162,
        "gal1RGexp" : 0.298,
        "gal4RGsig" : 1.6899E-9,
        "name" : "YJL219W",
        "COMMON" : "HXT9",
        "SUID" : 312,
        "gal4RGexp" : 0.592,
        "selected" : false,
        "gal80Rsig" : 0.097946
      },
      "position" : {
        "x" : -861.7066627701347,
        "y" : -16.686951006824387
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "310",
        "shared_name" : "YLL021W",
        "gal1RGsig" : 3.4013E-4,
        "gal80Rexp" : -0.036,
        "gal1RGexp" : -0.155,
        "gal4RGsig" : 0.23036,
        "name" : "YLL021W",
        "COMMON" : "SPA2",
        "SUID" : 310,
        "gal4RGexp" : 0.05,
        "selected" : false,
        "gal80Rsig" : 0.62229
      },
      "position" : {
        "x" : 412.01829755701374,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "308",
        "shared_name" : "YOL136C",
        "gal1RGsig" : 1.9054E-8,
        "gal80Rexp" : -0.472,
        "gal1RGexp" : -0.646,
        "gal4RGsig" : 0.39614,
        "name" : "YOL136C",
        "COMMON" : "PFK27",
        "SUID" : 308,
        "gal4RGexp" : -0.086,
        "selected" : false,
        "gal80Rsig" : 0.0081753
      },
      "position" : {
        "x" : 312.01829755701374,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "307",
        "shared_name" : "YJL203W",
        "gal1RGsig" : 0.13783,
        "gal80Rexp" : 0.401,
        "gal1RGexp" : 0.083,
        "gal4RGsig" : 6.541E-4,
        "name" : "YJL203W",
        "COMMON" : "PRP21",
        "SUID" : 307,
        "gal4RGexp" : -0.46,
        "selected" : false,
        "gal80Rsig" : 0.0046881
      },
      "position" : {
        "x" : 212.01829755701374,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "304",
        "shared_name" : "YNR007C",
        "gal1RGsig" : 0.061024,
        "gal80Rexp" : 0.161,
        "gal1RGexp" : 0.078,
        "gal4RGsig" : 3.1083E-4,
        "name" : "YNR007C",
        "COMMON" : "AUT1",
        "SUID" : 304,
        "gal4RGexp" : 0.196,
        "selected" : false,
        "gal80Rsig" : 0.10191
      },
      "position" : {
        "x" : 112.01829755701374,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "301",
        "shared_name" : "YFL026W",
        "gal1RGsig" : 1.3644E-10,
        "gal80Rexp" : -0.74,
        "gal1RGexp" : -0.653,
        "gal4RGsig" : 4.1738E-6,
        "name" : "YFL026W",
        "COMMON" : "STE2",
        "SUID" : 301,
        "gal4RGexp" : -0.396,
        "selected" : false,
        "gal80Rsig" : 2.884E-14
      },
      "position" : {
        "x" : -569.7704292496269,
        "y" : -1059.387457803651
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "299",
        "shared_name" : "YJL157C",
        "gal1RGsig" : 5.9763E-4,
        "gal80Rexp" : 0.972,
        "gal1RGexp" : -0.158,
        "gal4RGsig" : 4.7408E-8,
        "name" : "YJL157C",
        "COMMON" : "FAR1",
        "SUID" : 299,
        "gal4RGexp" : -0.803,
        "selected" : false,
        "gal80Rsig" : 6.3708E-7
      },
      "position" : {
        "x" : -465.238233204705,
        "y" : -929.8223332919323
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "297",
        "shared_name" : "YNL145W",
        "gal1RGsig" : 3.148E-11,
        "gal80Rexp" : -1.237,
        "gal1RGexp" : -0.764,
        "gal4RGsig" : 0.05338,
        "name" : "YNL145W",
        "COMMON" : "MFA2",
        "SUID" : 297,
        "gal4RGexp" : -0.098,
        "selected" : false,
        "gal80Rsig" : 1.1916E-10
      },
      "position" : {
        "x" : -573.8528267105644,
        "y" : -1108.6015080966197
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "295",
        "shared_name" : "YDR461W",
        "gal1RGsig" : 2.4721E-10,
        "gal80Rexp" : -0.526,
        "gal1RGexp" : -0.659,
        "gal4RGsig" : 0.011212,
        "name" : "YDR461W",
        "COMMON" : "MFA1",
        "SUID" : 295,
        "gal4RGexp" : -0.147,
        "selected" : false,
        "gal80Rsig" : 5.5223E-10
      },
      "position" : {
        "x" : -595.7450996597831,
        "y" : -1015.346442178651
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "293",
        "shared_name" : "YGR108W",
        "gal1RGsig" : 7.5764E-7,
        "gal80Rexp" : 0.101,
        "gal1RGexp" : -0.25,
        "gal4RGsig" : 2.3869E-7,
        "name" : "YGR108W",
        "COMMON" : "CLB1",
        "SUID" : 293,
        "gal4RGexp" : -0.566,
        "selected" : false,
        "gal80Rsig" : 0.1936
      },
      "position" : {
        "x" : -479.522901173455,
        "y" : -1186.118445352479
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "291",
        "shared_name" : "YKR097W",
        "gal1RGsig" : 7.092E-13,
        "gal80Rexp" : 0.123,
        "gal1RGexp" : 1.289,
        "gal4RGsig" : 1.8547E-10,
        "name" : "YKR097W",
        "COMMON" : "PCK1",
        "SUID" : 291,
        "gal4RGexp" : 1.224,
        "selected" : false,
        "gal80Rsig" : 0.13819
      },
      "position" : {
        "x" : -270.60000478826214,
        "y" : -1092.4036321200572
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "289",
        "shared_name" : "YJL159W",
        "gal1RGsig" : 6.8879E-8,
        "gal80Rexp" : 0.001,
        "gal1RGexp" : -0.357,
        "gal4RGsig" : 0.041194,
        "name" : "YJL159W",
        "COMMON" : "HSP150",
        "SUID" : 289,
        "gal4RGexp" : 0.111,
        "selected" : false,
        "gal80Rsig" : 0.999999
      },
      "position" : {
        "x" : -329.3338905533378,
        "y" : -963.2907170809948
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "287",
        "shared_name" : "YIL015W",
        "gal1RGsig" : 7.0996E-11,
        "gal80Rexp" : -1.117,
        "gal1RGexp" : -0.622,
        "gal4RGsig" : 0.0040782,
        "name" : "YIL015W",
        "COMMON" : "BAR1",
        "SUID" : 287,
        "gal4RGexp" : -0.207,
        "selected" : false,
        "gal80Rsig" : 2.9167E-11
      },
      "position" : {
        "x" : -549.5584236343925,
        "y" : -1163.229987100526
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "286",
        "shared_name" : "YMR043W",
        "gal1RGsig" : 0.0035372,
        "gal80Rexp" : 0.457,
        "gal1RGexp" : -0.183,
        "gal4RGsig" : 4.2514E-6,
        "name" : "YMR043W",
        "COMMON" : "MCM1",
        "SUID" : 286,
        "gal4RGexp" : -0.654,
        "selected" : false,
        "gal80Rsig" : 2.4112E-4
      },
      "position" : {
        "x" : -437.42564165197064,
        "y" : -1066.8811711825572
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "281",
        "shared_name" : "YKL109W",
        "gal1RGsig" : 0.045375,
        "gal80Rexp" : -0.117,
        "gal1RGexp" : 0.084,
        "gal4RGsig" : 3.1802E-6,
        "name" : "YKL109W",
        "COMMON" : "HAP4",
        "SUID" : 281,
        "gal4RGexp" : 0.295,
        "selected" : false,
        "gal80Rsig" : 0.071395
      },
      "position" : {
        "x" : 24.192278269904364,
        "y" : -1557.5272588290416
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "279",
        "shared_name" : "YBR217W",
        "gal1RGsig" : 0.143,
        "gal80Rexp" : 0.378,
        "gal1RGexp" : 0.088,
        "gal4RGsig" : 0.011008,
        "name" : "YBR217W",
        "COMMON" : "APG12",
        "SUID" : 279,
        "gal4RGexp" : -0.332,
        "selected" : false,
        "gal80Rsig" : 0.012775
      },
      "position" : {
        "x" : 12.018297557013739,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "277",
        "shared_name" : "YHR171W",
        "gal1RGsig" : 0.030789,
        "gal80Rexp" : 0.034,
        "gal1RGexp" : -0.134,
        "gal4RGsig" : 2.257E-4,
        "name" : "YHR171W",
        "COMMON" : "APG7",
        "SUID" : 277,
        "gal4RGexp" : 0.251,
        "selected" : false,
        "gal80Rsig" : 0.7782
      },
      "position" : {
        "x" : -87.98170244298626,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "276",
        "shared_name" : "YPL149W",
        "gal1RGsig" : 0.47027,
        "gal80Rexp" : 0.488,
        "gal1RGexp" : 0.033,
        "gal4RGsig" : 0.043291,
        "name" : "YPL149W",
        "COMMON" : "APG5",
        "SUID" : 276,
        "gal4RGexp" : 0.116,
        "selected" : false,
        "gal80Rsig" : 1.5579E-5
      },
      "position" : {
        "x" : -187.98170244298626,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "274",
        "shared_name" : "YKL028W",
        "gal1RGsig" : 3.5042E-5,
        "gal80Rexp" : 0.337,
        "gal1RGexp" : 0.214,
        "gal4RGsig" : 0.025221,
        "name" : "YKL028W",
        "COMMON" : "TFA1",
        "SUID" : 274,
        "gal4RGexp" : -0.146,
        "selected" : false,
        "gal80Rsig" : 4.9898E-5
      },
      "position" : {
        "x" : -287.98170244298626,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "273",
        "shared_name" : "YDR311W",
        "gal1RGsig" : 0.056092,
        "gal80Rexp" : 0.332,
        "gal1RGexp" : 0.098,
        "gal4RGsig" : 0.60829,
        "name" : "YDR311W",
        "COMMON" : "TFB1",
        "SUID" : 273,
        "gal4RGexp" : -0.043,
        "selected" : false,
        "gal80Rsig" : 0.0087786
      },
      "position" : {
        "x" : -387.98170244298626,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "271",
        "shared_name" : "YBL021C",
        "gal1RGsig" : 0.18207,
        "gal80Rexp" : -0.108,
        "gal1RGexp" : 0.073,
        "gal4RGsig" : 0.015004,
        "name" : "YBL021C",
        "COMMON" : "HAP3",
        "SUID" : 271,
        "gal4RGexp" : -0.256,
        "selected" : false,
        "gal80Rsig" : 0.497
      },
      "position" : {
        "x" : 261.84794843592,
        "y" : -1674.0185899295054
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "269",
        "shared_name" : "YGL237C",
        "gal1RGsig" : 0.002588,
        "gal80Rexp" : 0.059,
        "gal1RGexp" : 0.127,
        "gal4RGsig" : 0.22211,
        "name" : "YGL237C",
        "COMMON" : "HAP2",
        "SUID" : 269,
        "gal4RGexp" : 0.05,
        "selected" : false,
        "gal80Rsig" : 0.35299
      },
      "position" : {
        "x" : 181.0699943343575,
        "y" : -1718.7377614535533
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "267",
        "shared_name" : "YEL039C",
        "gal1RGsig" : 2.8783E-6,
        "gal80Rexp" : -1.373,
        "gal1RGexp" : -0.319,
        "gal4RGsig" : 7.3568E-7,
        "name" : "YEL039C",
        "COMMON" : "CYC7",
        "SUID" : 267,
        "gal4RGexp" : 0.377,
        "selected" : false,
        "gal80Rsig" : 4.9668E-7
      },
      "position" : {
        "x" : 449.314989451545,
        "y" : -1568.9997167147837
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "265",
        "shared_name" : "YJR048W",
        "gal1RGsig" : 3.3444E-5,
        "gal80Rexp" : -0.643,
        "gal1RGexp" : 0.216,
        "gal4RGsig" : 0.005959,
        "name" : "YJR048W",
        "COMMON" : "CYC1",
        "SUID" : 265,
        "gal4RGexp" : 0.14,
        "selected" : true,
        "gal80Rsig" : 1.6071E-8
      },
      "position" : {
        "x" : 173.43309247888874,
        "y" : -1597.060412362977
      },
      "selected" : true
    }, {
      "data" : {
        "id" : "263",
        "shared_name" : "YML054C",
        "gal1RGsig" : 3.5964E-11,
        "gal80Rexp" : -0.091,
        "gal1RGexp" : 0.963,
        "gal4RGsig" : 1.3947E-8,
        "name" : "YML054C",
        "COMMON" : "CYB2",
        "SUID" : 263,
        "gal4RGexp" : 0.856,
        "selected" : false,
        "gal80Rsig" : 0.25421
      },
      "position" : {
        "x" : 466.84569013513874,
        "y" : -1669.3003863848887
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "262",
        "shared_name" : "YLR256W",
        "gal1RGsig" : 0.79725,
        "gal80Rexp" : 0.104,
        "gal1RGexp" : 0.011,
        "gal4RGsig" : 0.063023,
        "name" : "YLR256W",
        "COMMON" : "HAP1",
        "SUID" : 262,
        "gal4RGexp" : -0.087,
        "selected" : false,
        "gal80Rsig" : 0.2243
      },
      "position" : {
        "x" : 344.65245283045124,
        "y" : -1633.5055093325816
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "260",
        "shared_name" : "YOR303W",
        "gal1RGsig" : 0.002137,
        "gal80Rexp" : 0.403,
        "gal1RGexp" : -0.127,
        "gal4RGsig" : 0.15221,
        "name" : "YOR303W",
        "COMMON" : "CPA1",
        "SUID" : 260,
        "gal4RGexp" : -0.089,
        "selected" : false,
        "gal80Rsig" : 1.5854E-4
      },
      "position" : {
        "x" : -487.98170244298626,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "259",
        "shared_name" : "YJR109C",
        "gal1RGsig" : 1.2917E-7,
        "gal80Rexp" : -0.745,
        "gal1RGexp" : -0.323,
        "gal4RGsig" : 0.61381,
        "name" : "YJR109C",
        "COMMON" : "CPA2",
        "SUID" : 259,
        "gal4RGexp" : -0.0,
        "selected" : false,
        "gal80Rsig" : 0.030981
      },
      "position" : {
        "x" : -587.9817024429863,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "257",
        "shared_name" : "YGR058W",
        "gal1RGsig" : 0.44242,
        "gal80Rexp" : -0.065,
        "gal1RGexp" : 0.045,
        "gal4RGsig" : 0.10763,
        "name" : "YGR058W",
        "COMMON" : "YGR058W",
        "SUID" : 257,
        "gal4RGexp" : -0.16,
        "selected" : false,
        "gal80Rsig" : 0.6708
      },
      "position" : {
        "x" : -687.9817024429863,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "255",
        "shared_name" : "YLR229C",
        "gal1RGsig" : 0.066961,
        "gal80Rexp" : -0.154,
        "gal1RGexp" : -0.074,
        "gal4RGsig" : 0.031442,
        "name" : "YLR229C",
        "COMMON" : "CDC42",
        "SUID" : 255,
        "gal4RGexp" : 0.089,
        "selected" : false,
        "gal80Rsig" : 0.030339
      },
      "position" : {
        "x" : -787.9817024429863,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "254",
        "shared_name" : "YDR309C",
        "gal1RGsig" : 1.6598E-8,
        "gal80Rexp" : -0.798,
        "gal1RGexp" : -0.427,
        "gal4RGsig" : 0.032663,
        "name" : "YDR309C",
        "COMMON" : "GIC2",
        "SUID" : 254,
        "gal4RGexp" : -0.129,
        "selected" : false,
        "gal80Rsig" : 1.2554E-13
      },
      "position" : {
        "x" : -887.9817024429863,
        "y" : 810.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "252",
        "shared_name" : "YOR264W",
        "gal1RGsig" : 1.939E-8,
        "gal80Rexp" : 0.307,
        "gal1RGexp" : 0.493,
        "gal4RGsig" : 0.016862,
        "name" : "YOR264W",
        "COMMON" : "YOR264W",
        "SUID" : 252,
        "gal4RGexp" : 0.237,
        "selected" : false,
        "gal80Rsig" : 0.011809
      },
      "position" : {
        "x" : 1012.0182975570137,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "250",
        "shared_name" : "YLR116W",
        "gal1RGsig" : 0.74865,
        "gal80Rexp" : 0.101,
        "gal1RGexp" : 0.015,
        "gal4RGsig" : 0.60558,
        "name" : "YLR116W",
        "COMMON" : "MSL5",
        "SUID" : 250,
        "gal4RGexp" : -0.03,
        "selected" : false,
        "gal80Rsig" : 0.35769
      },
      "position" : {
        "x" : 912.0182975570137,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "248",
        "shared_name" : "YNL312W",
        "gal1RGsig" : 0.47284,
        "gal80Rexp" : -0.121,
        "gal1RGexp" : 0.028,
        "gal4RGsig" : 0.034589,
        "name" : "YNL312W",
        "COMMON" : "RFA2",
        "SUID" : 248,
        "gal4RGexp" : -0.111,
        "selected" : false,
        "gal80Rsig" : 0.24786
      },
      "position" : {
        "x" : -482.7377144058769,
        "y" : -19.070242251331223
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "247",
        "shared_name" : "YML032C",
        "gal1RGsig" : 3.3893E-4,
        "gal80Rexp" : 0.363,
        "gal1RGexp" : 0.199,
        "gal4RGsig" : 0.033332,
        "name" : "YML032C",
        "COMMON" : "RAD52",
        "SUID" : 247,
        "gal4RGexp" : -0.136,
        "selected" : false,
        "gal80Rsig" : 0.0030735
      },
      "position" : {
        "x" : 812.0182975570137,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "245",
        "shared_name" : "YKL012W",
        "gal1RGsig" : 4.2719E-4,
        "gal80Rexp" : 0.561,
        "gal1RGexp" : 0.21,
        "gal4RGsig" : 3.5398E-4,
        "name" : "YKL012W",
        "COMMON" : "PRP40",
        "SUID" : 245,
        "gal4RGexp" : -0.277,
        "selected" : false,
        "gal80Rsig" : 8.7173E-5
      },
      "position" : {
        "x" : 712.0182975570137,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "244",
        "shared_name" : "YNL236W",
        "gal1RGsig" : 0.018347,
        "gal80Rexp" : -0.141,
        "gal1RGexp" : -0.146,
        "gal4RGsig" : 0.053936,
        "name" : "YNL236W",
        "COMMON" : "SIN4",
        "SUID" : 244,
        "gal4RGexp" : -0.218,
        "selected" : false,
        "gal80Rsig" : 0.39009
      },
      "position" : {
        "x" : 612.0182975570137,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "242",
        "shared_name" : "YNL091W",
        "gal1RGsig" : 1.9735E-6,
        "gal80Rexp" : 0.723,
        "gal1RGexp" : 0.288,
        "gal4RGsig" : 0.026384,
        "name" : "YNL091W",
        "COMMON" : "YNL091W",
        "SUID" : 242,
        "gal4RGexp" : 0.154,
        "selected" : false,
        "gal80Rsig" : 2.3704E-4
      },
      "position" : {
        "x" : 512.0182975570137,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "240",
        "shared_name" : "YDR184C",
        "gal1RGsig" : 0.4641,
        "gal80Rexp" : 0.404,
        "gal1RGexp" : 0.04,
        "gal4RGsig" : 9.3996E-7,
        "name" : "YDR184C",
        "COMMON" : "ATC1",
        "SUID" : 240,
        "gal4RGexp" : -0.886,
        "selected" : false,
        "gal80Rsig" : 0.10407
      },
      "position" : {
        "x" : 312.01829755701374,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "238",
        "shared_name" : "YIL143C",
        "gal1RGsig" : 0.019613,
        "gal80Rexp" : 0.264,
        "gal1RGexp" : 0.124,
        "gal4RGsig" : 0.36733,
        "name" : "YIL143C",
        "COMMON" : "SSL2",
        "SUID" : 238,
        "gal4RGexp" : 0.069,
        "selected" : false,
        "gal80Rsig" : 0.045357
      },
      "position" : {
        "x" : 112.01829755701374,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "236",
        "shared_name" : "YKR099W",
        "gal1RGsig" : 6.1231E-6,
        "gal80Rexp" : 1.101,
        "gal1RGexp" : 0.466,
        "gal4RGsig" : 7.6476E-6,
        "name" : "YKR099W",
        "COMMON" : "BAS1",
        "SUID" : 236,
        "gal4RGexp" : -0.936,
        "selected" : false,
        "gal80Rsig" : 6.9896E-4
      },
      "position" : {
        "x" : -168.29846727452923,
        "y" : -1722.6238088168345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "235",
        "shared_name" : "YIR009W",
        "gal1RGsig" : 0.74397,
        "gal80Rexp" : -0.049,
        "gal1RGexp" : -0.044,
        "gal4RGsig" : 0.19987,
        "name" : "YIR009W",
        "COMMON" : "MSL1",
        "SUID" : 235,
        "gal4RGexp" : -0.337,
        "selected" : false,
        "gal80Rsig" : 0.89526
      },
      "position" : {
        "x" : -87.98170244298626,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "233",
        "shared_name" : "YBR018C",
        "gal1RGsig" : 7.8855E-4,
        "gal80Rexp" : 3.126,
        "gal1RGexp" : 0.153,
        "gal4RGsig" : 3.6284E-11,
        "name" : "YBR018C",
        "COMMON" : "GAL7",
        "SUID" : 233,
        "gal4RGexp" : -1.995,
        "selected" : true,
        "gal80Rsig" : 3.9427E-17
      },
      "position" : {
        "x" : 164.05397260584186,
        "y" : -1384.2254704989634
      },
      "selected" : true
    }, {
      "data" : {
        "id" : "231",
        "shared_name" : "YPL248C",
        "gal1RGsig" : 0.11614,
        "gal80Rexp" : -0.211,
        "gal1RGexp" : 0.1,
        "gal4RGsig" : 1.264E-4,
        "name" : "YPL248C",
        "COMMON" : "GAL4",
        "SUID" : 231,
        "gal4RGexp" : -0.758,
        "selected" : true,
        "gal80Rsig" : 0.088214
      },
      "position" : {
        "x" : 49.49711608886719,
        "y" : -1489.548583984375
      },
      "selected" : true
    }, {
      "data" : {
        "id" : "229",
        "shared_name" : "YLR081W",
        "gal1RGsig" : 2.4597E-4,
        "gal80Rexp" : 0.892,
        "gal1RGexp" : 0.176,
        "gal4RGsig" : 1.6652E-7,
        "name" : "YLR081W",
        "COMMON" : "GAL2",
        "SUID" : 229,
        "gal4RGexp" : -0.57,
        "selected" : true,
        "gal80Rsig" : 7.3429E-10
      },
      "position" : {
        "x" : 76.54855346679688,
        "y" : -1409.010986328125
      },
      "selected" : true
    }, {
      "data" : {
        "id" : "227",
        "shared_name" : "YBR020W",
        "gal1RGsig" : 7.0101E-9,
        "gal80Rexp" : 2.939,
        "gal1RGexp" : -2.426,
        "gal4RGsig" : 2.5038E-9,
        "name" : "YBR020W",
        "COMMON" : "GAL1",
        "SUID" : 227,
        "gal4RGexp" : -2.406,
        "selected" : true,
        "gal80Rsig" : 2.8147E-18
      },
      "position" : {
        "x" : -33.9830299576347,
        "y" : -1377.2427434481822
      },
      "selected" : true
    }, {
      "data" : {
        "id" : "225",
        "shared_name" : "YGL035C",
        "gal1RGsig" : 1.102E-7,
        "gal80Rexp" : -0.28,
        "gal1RGexp" : 0.345,
        "gal4RGsig" : 1.7172E-6,
        "name" : "YGL035C",
        "COMMON" : "MIG1",
        "SUID" : 225,
        "gal4RGexp" : 0.31,
        "selected" : true,
        "gal80Rsig" : 0.0070533
      },
      "position" : {
        "x" : -128.27950822911907,
        "y" : -1463.1631383456431
      },
      "selected" : true
    }, {
      "data" : {
        "id" : "223",
        "shared_name" : "YOL051W",
        "gal1RGsig" : 0.001834,
        "gal80Rexp" : 0.111,
        "gal1RGexp" : 0.171,
        "gal4RGsig" : 0.33923,
        "name" : "YOL051W",
        "COMMON" : "GAL11",
        "SUID" : 223,
        "gal4RGexp" : 0.055,
        "selected" : true,
        "gal80Rsig" : 0.30922
      },
      "position" : {
        "x" : 69.69892883300781,
        "y" : -1325.6220703125
      },
      "selected" : true
    }, {
      "data" : {
        "id" : "222",
        "shared_name" : "YBR019C",
        "gal1RGsig" : 0.098603,
        "gal80Rexp" : 2.856,
        "gal1RGexp" : 0.061,
        "gal4RGsig" : 3.3164E-11,
        "name" : "YBR019C",
        "COMMON" : "GAL10",
        "SUID" : 222,
        "gal4RGexp" : -1.993,
        "selected" : true,
        "gal80Rsig" : 3.9398E-18
      },
      "position" : {
        "x" : -6.008908863884699,
        "y" : -1416.1922826327525
      },
      "selected" : true
    }, {
      "data" : {
        "id" : "220",
        "shared_name" : "YJR060W",
        "gal1RGsig" : 0.0013953,
        "gal80Rexp" : 0.103,
        "gal1RGexp" : 0.165,
        "gal4RGsig" : 0.0034755,
        "name" : "YJR060W",
        "COMMON" : "CBF1",
        "SUID" : 220,
        "gal4RGexp" : -0.306,
        "selected" : false,
        "gal80Rsig" : 0.43529
      },
      "position" : {
        "x" : -751.1624275406425,
        "y" : -1889.2249211825572
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "218",
        "shared_name" : "YDR103W",
        "gal1RGsig" : 0.34875,
        "gal80Rexp" : 0.023,
        "gal1RGexp" : -0.068,
        "gal4RGsig" : 0.42858,
        "name" : "YDR103W",
        "COMMON" : "STE5",
        "SUID" : 218,
        "gal4RGexp" : -0.121,
        "selected" : false,
        "gal80Rsig" : 0.92304
      },
      "position" : {
        "x" : -687.9817024429863,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "216",
        "shared_name" : "YLR362W",
        "gal1RGsig" : 0.023963,
        "gal80Rexp" : 0.374,
        "gal1RGexp" : 0.144,
        "gal4RGsig" : 0.50139,
        "name" : "YLR362W",
        "COMMON" : "STE11",
        "SUID" : 216,
        "gal4RGexp" : 0.037,
        "selected" : false,
        "gal80Rsig" : 0.0010869
      },
      "position" : {
        "x" : -887.9817024429863,
        "y" : 710.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "214",
        "shared_name" : "YDR032C",
        "gal1RGsig" : 0.026191,
        "gal80Rexp" : -0.211,
        "gal1RGexp" : 0.113,
        "gal4RGsig" : 2.0333E-6,
        "name" : "YDR032C",
        "COMMON" : "YDR032C",
        "SUID" : 214,
        "gal4RGexp" : 0.331,
        "selected" : false,
        "gal80Rsig" : 7.1391E-4
      },
      "position" : {
        "x" : 812.0182975570137,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "213",
        "shared_name" : "YCL032W",
        "gal1RGsig" : 0.003766,
        "gal80Rexp" : 0.284,
        "gal1RGexp" : 0.126,
        "gal4RGsig" : 0.71364,
        "name" : "YCL032W",
        "COMMON" : "STE50",
        "SUID" : 213,
        "gal4RGexp" : 0.02,
        "selected" : false,
        "gal80Rsig" : 0.015244
      },
      "position" : {
        "x" : 712.0182975570137,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "211",
        "shared_name" : "YLR109W",
        "gal1RGsig" : 1.4814E-9,
        "gal80Rexp" : -0.486,
        "gal1RGexp" : -0.603,
        "gal4RGsig" : 2.5668E-4,
        "name" : "YLR109W",
        "COMMON" : "AHP1",
        "SUID" : 211,
        "gal4RGexp" : 0.466,
        "selected" : false,
        "gal80Rsig" : 2.3432E-11
      },
      "position" : {
        "x" : 512.0182975570137,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "209",
        "shared_name" : "YHR141C",
        "gal1RGsig" : 7.7434E-7,
        "gal80Rexp" : -0.139,
        "gal1RGexp" : -0.359,
        "gal4RGsig" : 2.5233E-6,
        "name" : "YHR141C",
        "COMMON" : "RPL42B",
        "SUID" : 209,
        "gal4RGexp" : -0.371,
        "selected" : false,
        "gal80Rsig" : 0.012998
      },
      "position" : {
        "x" : 412.01829755701374,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "208",
        "shared_name" : "YMR138W",
        "gal1RGsig" : 0.037256,
        "gal80Rexp" : 0.221,
        "gal1RGexp" : 0.414,
        "gal4RGsig" : 0.39944,
        "name" : "YMR138W",
        "COMMON" : "CIN4",
        "SUID" : 208,
        "gal4RGexp" : -0.0,
        "selected" : false,
        "gal80Rsig" : 0.12805
      },
      "position" : {
        "x" : 212.01829755701374,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "206",
        "shared_name" : "YMR300C",
        "gal1RGsig" : 1.522E-9,
        "gal80Rexp" : 1.202,
        "gal1RGexp" : -0.514,
        "gal4RGsig" : 1.4734E-8,
        "name" : "YMR300C",
        "COMMON" : "ADE4",
        "SUID" : 206,
        "gal4RGexp" : -1.296,
        "selected" : false,
        "gal80Rsig" : 4.7716E-11
      },
      "position" : {
        "x" : -228.75252496801068,
        "y" : -2130.0784673251355
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "204",
        "shared_name" : "YOL058W",
        "gal1RGsig" : 4.9342E-6,
        "gal80Rexp" : -0.815,
        "gal1RGexp" : -0.652,
        "gal4RGsig" : 4.0958E-7,
        "name" : "YOL058W",
        "COMMON" : "ARG1",
        "SUID" : 204,
        "gal4RGexp" : -0.541,
        "selected" : false,
        "gal80Rsig" : 5.9432E-10
      },
      "position" : {
        "x" : -157.10803758702923,
        "y" : -2141.6170415438855
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "202",
        "shared_name" : "YBR248C",
        "gal1RGsig" : 2.3151E-6,
        "gal80Rexp" : 0.898,
        "gal1RGexp" : -0.258,
        "gal4RGsig" : 1.6549E-7,
        "name" : "YBR248C",
        "COMMON" : "HIS7",
        "SUID" : 202,
        "gal4RGexp" : -1.252,
        "selected" : false,
        "gal80Rsig" : 3.3047E-5
      },
      "position" : {
        "x" : -52.75111162267376,
        "y" : -2023.422858194276
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "199",
        "shared_name" : "YOR202W",
        "gal1RGsig" : 0.010979,
        "gal80Rexp" : 0.239,
        "gal1RGexp" : -0.432,
        "gal4RGsig" : 1.7979E-4,
        "name" : "YOR202W",
        "COMMON" : "HIS3",
        "SUID" : 199,
        "gal4RGexp" : -0.71,
        "selected" : false,
        "gal80Rsig" : 0.0054895
      },
      "position" : {
        "x" : -103.33193742833782,
        "y" : -1896.8629064120494
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "197",
        "shared_name" : "YMR108W",
        "gal1RGsig" : 0.27002,
        "gal80Rexp" : 0.095,
        "gal1RGexp" : 0.04,
        "gal4RGsig" : 9.4314E-4,
        "name" : "YMR108W",
        "COMMON" : "ILV2",
        "SUID" : 197,
        "gal4RGexp" : -0.358,
        "selected" : false,
        "gal80Rsig" : 0.14717
      },
      "position" : {
        "x" : -84.8740211685722,
        "y" : -2103.717017129823
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "196",
        "shared_name" : "YEL009C",
        "gal1RGsig" : 0.33125,
        "gal80Rexp" : -0.031,
        "gal1RGexp" : 0.035,
        "gal4RGsig" : 0.41727,
        "name" : "YEL009C",
        "COMMON" : "GCN4",
        "SUID" : 196,
        "gal4RGexp" : 0.032,
        "selected" : false,
        "gal80Rsig" : 0.55639
      },
      "position" : {
        "x" : -175.90074693761517,
        "y" : -2008.821783975526
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "194",
        "shared_name" : "YBR155W",
        "gal1RGsig" : 0.10014,
        "gal80Rexp" : 0.519,
        "gal1RGexp" : 0.082,
        "gal4RGsig" : 1.5959E-5,
        "name" : "YBR155W",
        "COMMON" : "CNS1",
        "SUID" : 194,
        "gal4RGexp" : -0.479,
        "selected" : false,
        "gal80Rsig" : 3.7064E-4
      },
      "position" : {
        "x" : -387.98170244298626,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "193",
        "shared_name" : "YMR186W",
        "gal1RGsig" : 0.52469,
        "gal80Rexp" : -0.608,
        "gal1RGexp" : -0.032,
        "gal4RGsig" : 0.4995,
        "name" : "YMR186W",
        "COMMON" : "HSC82",
        "SUID" : 193,
        "gal4RGexp" : -0.032,
        "selected" : false,
        "gal80Rsig" : 1.6833E-14
      },
      "position" : {
        "x" : -587.9817024429863,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "191",
        "shared_name" : "YGL106W",
        "gal1RGsig" : 1.3141E-5,
        "gal80Rexp" : -0.059,
        "gal1RGexp" : -0.262,
        "gal4RGsig" : 9.2389E-6,
        "name" : "YGL106W",
        "COMMON" : "MLC1",
        "SUID" : 191,
        "gal4RGexp" : -0.327,
        "selected" : false,
        "gal80Rsig" : 0.29618
      },
      "position" : {
        "x" : -687.9817024429863,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "190",
        "shared_name" : "YOR326W",
        "gal1RGsig" : 5.9183E-9,
        "gal80Rexp" : 0.296,
        "gal1RGexp" : 0.51,
        "gal4RGsig" : 8.2407E-8,
        "name" : "YOR326W",
        "COMMON" : "MYO2",
        "SUID" : 190,
        "gal4RGexp" : 0.432,
        "selected" : false,
        "gal80Rsig" : 1.1583E-4
      },
      "position" : {
        "x" : -887.9817024429863,
        "y" : 610.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "187",
        "shared_name" : "YMR309C",
        "gal1RGsig" : 0.82076,
        "gal80Rexp" : -0.123,
        "gal1RGexp" : 0.009,
        "gal4RGsig" : 2.0319E-4,
        "name" : "YMR309C",
        "COMMON" : "NIP1",
        "SUID" : 187,
        "gal4RGexp" : -0.248,
        "selected" : false,
        "gal80Rsig" : 0.1009
      },
      "position" : {
        "x" : 1012.0182975570137,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "186",
        "shared_name" : "YOR361C",
        "gal1RGsig" : 0.60784,
        "gal80Rexp" : -0.237,
        "gal1RGexp" : -0.02,
        "gal4RGsig" : 0.11638,
        "name" : "YOR361C",
        "COMMON" : "PRT1",
        "SUID" : 186,
        "gal4RGexp" : -0.085,
        "selected" : false,
        "gal80Rsig" : 0.0031451
      },
      "position" : {
        "x" : 912.0182975570137,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "184",
        "shared_name" : "YIL105C",
        "gal1RGsig" : 6.9834E-5,
        "gal80Rexp" : 0.197,
        "gal1RGexp" : 0.196,
        "gal4RGsig" : 0.66796,
        "name" : "YIL105C",
        "COMMON" : "YIL105C",
        "SUID" : 184,
        "gal4RGexp" : 0.023,
        "selected" : false,
        "gal80Rsig" : 0.016148
      },
      "position" : {
        "x" : 712.0182975570137,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "182",
        "shared_name" : "YLR134W",
        "gal1RGsig" : 1.2585E-11,
        "gal80Rexp" : -0.351,
        "gal1RGexp" : -0.645,
        "gal4RGsig" : 0.58514,
        "name" : "YLR134W",
        "COMMON" : "PDC5",
        "SUID" : 182,
        "gal4RGexp" : 0.027,
        "selected" : false,
        "gal80Rsig" : 1.2076E-8
      },
      "position" : {
        "x" : 512.0182975570137,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "180",
        "shared_name" : "YER179W",
        "gal1RGsig" : 1.1807E-4,
        "gal80Rexp" : -0.167,
        "gal1RGexp" : -0.219,
        "gal4RGsig" : 0.36733,
        "name" : "YER179W",
        "COMMON" : "DMC1",
        "SUID" : 180,
        "gal4RGexp" : 0.059,
        "selected" : false,
        "gal80Rsig" : 0.13801
      },
      "position" : {
        "x" : 312.01829755701374,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "178",
        "shared_name" : "YOR310C",
        "gal1RGsig" : 0.055533,
        "gal80Rexp" : -0.157,
        "gal1RGexp" : -0.073,
        "gal4RGsig" : 1.7322E-6,
        "name" : "YOR310C",
        "COMMON" : "NOP5",
        "SUID" : 178,
        "gal4RGexp" : -0.499,
        "selected" : false,
        "gal80Rsig" : 0.041898
      },
      "position" : {
        "x" : 112.01829755701374,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177",
        "shared_name" : "YDL014W",
        "gal1RGsig" : 0.32352,
        "gal80Rexp" : -0.038,
        "gal1RGexp" : -0.039,
        "gal4RGsig" : 0.012945,
        "name" : "YDL014W",
        "COMMON" : "NOP1",
        "SUID" : 177,
        "gal4RGexp" : -0.176,
        "selected" : false,
        "gal80Rsig" : 0.62955
      },
      "position" : {
        "x" : 12.018297557013739,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "175",
        "shared_name" : "YPR119W",
        "gal1RGsig" : 3.9246E-6,
        "gal80Rexp" : -0.342,
        "gal1RGexp" : -0.234,
        "gal4RGsig" : 6.2635E-4,
        "name" : "YPR119W",
        "COMMON" : "CLB2",
        "SUID" : 175,
        "gal4RGexp" : -0.279,
        "selected" : false,
        "gal80Rsig" : 1.6424E-5
      },
      "position" : {
        "x" : -322.19126665197064,
        "y" : -1032.648688272401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "173",
        "shared_name" : "YLR117C",
        "gal1RGsig" : 7.6184E-7,
        "gal80Rexp" : 0.712,
        "gal1RGexp" : 0.326,
        "gal4RGsig" : 0.0048407,
        "name" : "YLR117C",
        "COMMON" : "SYF3",
        "SUID" : 173,
        "gal4RGexp" : -0.234,
        "selected" : false,
        "gal80Rsig" : 6.8931E-6
      },
      "position" : {
        "x" : -287.98170244298626,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "171",
        "shared_name" : "YGL013C",
        "gal1RGsig" : 1.959E-4,
        "gal80Rexp" : 0.173,
        "gal1RGexp" : 0.185,
        "gal4RGsig" : 0.013422,
        "name" : "YGL013C",
        "COMMON" : "PDR1",
        "SUID" : 171,
        "gal4RGexp" : -0.152,
        "selected" : false,
        "gal80Rsig" : 0.0945
      },
      "position" : {
        "x" : -887.9817024429863,
        "y" : -123.55411371129216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "169",
        "shared_name" : "YCR086W",
        "gal1RGsig" : 0.32121,
        "gal80Rexp" : 0.381,
        "gal1RGexp" : -0.081,
        "gal4RGsig" : 0.080473,
        "name" : "YCR086W",
        "COMMON" : "YCR086W",
        "SUID" : 169,
        "gal4RGexp" : -0.397,
        "selected" : false,
        "gal80Rsig" : 0.17239
      },
      "position" : {
        "x" : -487.98170244298626,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "168",
        "shared_name" : "YDR412W",
        "gal1RGsig" : 0.27226,
        "gal80Rexp" : 0.991,
        "gal1RGexp" : 0.067,
        "gal4RGsig" : 1.6949E-5,
        "name" : "YDR412W",
        "COMMON" : "YDR412W",
        "SUID" : 168,
        "gal4RGexp" : -0.641,
        "selected" : false,
        "gal80Rsig" : 2.4711E-5
      },
      "position" : {
        "x" : -587.9817024429863,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "166",
        "shared_name" : "YPL201C",
        "gal1RGsig" : 6.0394E-10,
        "gal80Rexp" : 0.597,
        "gal1RGexp" : 2.058,
        "gal4RGsig" : 8.9209E-7,
        "name" : "YPL201C",
        "COMMON" : "YPL201C",
        "SUID" : 166,
        "gal4RGexp" : 1.18,
        "selected" : false,
        "gal80Rsig" : 0.0043411
      },
      "position" : {
        "x" : -687.9817024429863,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "165",
        "shared_name" : "YER062C",
        "gal1RGsig" : 3.7312E-10,
        "gal80Rexp" : 0.359,
        "gal1RGexp" : -0.486,
        "gal4RGsig" : 1.2051E-8,
        "name" : "YER062C",
        "COMMON" : "HOR2",
        "SUID" : 165,
        "gal4RGexp" : -0.942,
        "selected" : false,
        "gal80Rsig" : 5.8643E-6
      },
      "position" : {
        "x" : -887.9817024429863,
        "y" : 510.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "163",
        "shared_name" : "YOR327C",
        "gal1RGsig" : 6.9534E-6,
        "gal80Rexp" : 0.559,
        "gal1RGexp" : 0.249,
        "gal4RGsig" : 0.06928,
        "name" : "YOR327C",
        "COMMON" : "SNC2",
        "SUID" : 163,
        "gal4RGexp" : -0.112,
        "selected" : false,
        "gal80Rsig" : 4.4793E-5
      },
      "position" : {
        "x" : 912.0182975570137,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "161",
        "shared_name" : "YER143W",
        "gal1RGsig" : 5.6125E-6,
        "gal80Rexp" : 0.179,
        "gal1RGexp" : 0.282,
        "gal4RGsig" : 8.6796E-6,
        "name" : "YER143W",
        "COMMON" : "DDI1",
        "SUID" : 161,
        "gal4RGexp" : 0.255,
        "selected" : false,
        "gal80Rsig" : 0.018361
      },
      "position" : {
        "x" : 712.0182975570137,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "160",
        "shared_name" : "YAL030W",
        "gal1RGsig" : 0.18782,
        "gal80Rexp" : 0.003,
        "gal1RGexp" : -0.05,
        "gal4RGsig" : 0.55374,
        "name" : "YAL030W",
        "COMMON" : "SNC1",
        "SUID" : 160,
        "gal4RGexp" : 0.027,
        "selected" : false,
        "gal80Rsig" : 0.95396
      },
      "position" : {
        "x" : 612.0182975570137,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "158",
        "shared_name" : "YOL086C",
        "gal1RGsig" : 0.0039297,
        "gal80Rexp" : -0.322,
        "gal1RGexp" : -0.113,
        "gal4RGsig" : 3.2186E-4,
        "name" : "YOL086C",
        "COMMON" : "ADH1",
        "SUID" : 158,
        "gal4RGexp" : 0.245,
        "selected" : false,
        "gal80Rsig" : 1.3104E-5
      },
      "position" : {
        "x" : -435.0452858170097,
        "y" : -1678.4135942019664
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "156",
        "shared_name" : "YDR050C",
        "gal1RGsig" : 3.6468E-10,
        "gal80Rexp" : -0.728,
        "gal1RGexp" : -0.584,
        "gal4RGsig" : 0.48903,
        "name" : "YDR050C",
        "COMMON" : "TPI1",
        "SUID" : 156,
        "gal4RGexp" : 0.053,
        "selected" : false,
        "gal80Rsig" : 8.6735E-12
      },
      "position" : {
        "x" : -488.36256181798626,
        "y" : -1649.4497007884227
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "154",
        "shared_name" : "YOL127W",
        "gal1RGsig" : 4.4813E-4,
        "gal80Rexp" : 0.076,
        "gal1RGexp" : -0.192,
        "gal4RGsig" : 9.2415E-7,
        "name" : "YOL127W",
        "COMMON" : "RPL25",
        "SUID" : 154,
        "gal4RGexp" : -0.425,
        "selected" : false,
        "gal80Rsig" : 0.17224
      },
      "position" : {
        "x" : -364.2943779190605,
        "y" : -1705.9235982455455
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "151",
        "shared_name" : "YIL069C",
        "gal1RGsig" : 7.7038E-6,
        "gal80Rexp" : -0.018,
        "gal1RGexp" : -0.313,
        "gal4RGsig" : 1.0186E-6,
        "name" : "YIL069C",
        "COMMON" : "RPS24B",
        "SUID" : 151,
        "gal4RGexp" : -0.467,
        "selected" : false,
        "gal80Rsig" : 0.74944
      },
      "position" : {
        "x" : -554.8934150894706,
        "y" : -1909.6759404696666
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "149",
        "shared_name" : "YER074W",
        "gal1RGsig" : 1.8517E-5,
        "gal80Rexp" : -0.051,
        "gal1RGexp" : -0.262,
        "gal4RGsig" : 2.1168E-6,
        "name" : "YER074W",
        "COMMON" : "RPS24A",
        "SUID" : 149,
        "gal4RGexp" : -0.449,
        "selected" : false,
        "gal80Rsig" : 0.44216
      },
      "position" : {
        "x" : -346.33184587560345,
        "y" : -1780.9607228793345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "147",
        "shared_name" : "YBR093C",
        "gal1RGsig" : 2.3291E-7,
        "gal80Rexp" : -0.543,
        "gal1RGexp" : -0.704,
        "gal4RGsig" : 0.088763,
        "name" : "YBR093C",
        "COMMON" : "PHO5",
        "SUID" : 147,
        "gal4RGexp" : 0.075,
        "selected" : false,
        "gal80Rsig" : 3.6198E-13
      },
      "position" : {
        "x" : -645.47187578283,
        "y" : -1745.0505513705455
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "145",
        "shared_name" : "YDR171W",
        "gal1RGsig" : 8.1757E-7,
        "gal80Rexp" : -0.723,
        "gal1RGexp" : -0.31,
        "gal4RGsig" : 8.7039E-6,
        "name" : "YDR171W",
        "COMMON" : "HSP42",
        "SUID" : 145,
        "gal4RGexp" : 0.3,
        "selected" : false,
        "gal80Rsig" : 1.4287E-12
      },
      "position" : {
        "x" : 112.01829755701374,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "143",
        "shared_name" : "YCL030C",
        "gal1RGsig" : 3.8988E-11,
        "gal80Rexp" : 0.29,
        "gal1RGexp" : -1.067,
        "gal4RGsig" : 2.3894E-7,
        "name" : "YCL030C",
        "COMMON" : "HIS4",
        "SUID" : 143,
        "gal4RGexp" : -0.898,
        "selected" : false,
        "gal80Rsig" : 0.0016438
      },
      "position" : {
        "x" : -269.51766645513226,
        "y" : -1851.0782079257212
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "141",
        "shared_name" : "YNL301C",
        "gal1RGsig" : 7.3086E-7,
        "gal80Rexp" : -0.271,
        "gal1RGexp" : -0.379,
        "gal4RGsig" : 1.0721E-4,
        "name" : "YNL301C",
        "COMMON" : "RPL18B",
        "SUID" : 141,
        "gal4RGexp" : -0.245,
        "selected" : false,
        "gal80Rsig" : 1.2267E-5
      },
      "position" : {
        "x" : -492.7341743668144,
        "y" : -1878.3558568515025
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "139",
        "shared_name" : "YOL120C",
        "gal1RGsig" : 1.7242E-7,
        "gal80Rexp" : -0.62,
        "gal1RGexp" : -0.409,
        "gal4RGsig" : 3.0221E-4,
        "name" : "YOL120C",
        "COMMON" : "RPL18A",
        "SUID" : 139,
        "gal4RGexp" : -0.225,
        "selected" : false,
        "gal80Rsig" : 3.898E-9
      },
      "position" : {
        "x" : -475.0254646500175,
        "y" : -1938.6291265048228
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "137",
        "shared_name" : "YLR044C",
        "gal1RGsig" : 6.9512E-11,
        "gal80Rexp" : -0.184,
        "gal1RGexp" : -0.62,
        "gal4RGsig" : 0.23784,
        "name" : "YLR044C",
        "COMMON" : "PDC1",
        "SUID" : 137,
        "gal4RGexp" : -0.071,
        "selected" : false,
        "gal80Rsig" : 0.0064407
      },
      "position" : {
        "x" : -296.1988846024101,
        "y" : -1612.973498300477
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "135",
        "shared_name" : "YIL133C",
        "gal1RGsig" : 4.6153E-8,
        "gal80Rexp" : -0.146,
        "gal1RGexp" : -0.453,
        "gal4RGsig" : 1.1962E-4,
        "name" : "YIL133C",
        "COMMON" : "RPL16A",
        "SUID" : 135,
        "gal4RGexp" : -0.311,
        "selected" : false,
        "gal80Rsig" : 0.012589
      },
      "position" : {
        "x" : -411.37876665197064,
        "y" : -1906.7141637362681
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "133",
        "shared_name" : "YHR174W",
        "gal1RGsig" : 7.175E-11,
        "gal80Rexp" : -0.217,
        "gal1RGexp" : -0.816,
        "gal4RGsig" : 0.011477,
        "name" : "YHR174W",
        "COMMON" : "ENO2",
        "SUID" : 133,
        "gal4RGexp" : 0.241,
        "selected" : false,
        "gal80Rsig" : 0.0015357
      },
      "position" : {
        "x" : -567.4564033707206,
        "y" : -1842.3973149813853
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "131",
        "shared_name" : "YGR254W",
        "gal1RGsig" : 6.5621E-11,
        "gal80Rexp" : -0.171,
        "gal1RGexp" : -0.737,
        "gal4RGsig" : 0.0079977,
        "name" : "YGR254W",
        "COMMON" : "ENO1",
        "SUID" : 131,
        "gal4RGexp" : 0.259,
        "selected" : false,
        "gal80Rsig" : 0.025056
      },
      "position" : {
        "x" : -593.3840461929863,
        "y" : -1702.2871198214732
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "129",
        "shared_name" : "YCR012W",
        "gal1RGsig" : 7.3129E-10,
        "gal80Rexp" : -0.746,
        "gal1RGexp" : -0.668,
        "gal4RGsig" : 2.4163E-5,
        "name" : "YCR012W",
        "COMMON" : "PGK1",
        "SUID" : 129,
        "gal4RGexp" : 0.329,
        "selected" : false,
        "gal80Rsig" : 4.2315E-13
      },
      "position" : {
        "x" : -626.6050850113456,
        "y" : -1824.9496526278697
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "128",
        "shared_name" : "YNL216W",
        "gal1RGsig" : 0.024692,
        "gal80Rexp" : 0.234,
        "gal1RGexp" : 0.205,
        "gal4RGsig" : 0.93493,
        "name" : "YNL216W",
        "COMMON" : "RAP1",
        "SUID" : 128,
        "gal4RGexp" : 0.015,
        "selected" : false,
        "gal80Rsig" : 0.54155
      },
      "position" : {
        "x" : -464.06512224279095,
        "y" : -1779.9281911410533
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "126",
        "shared_name" : "YAL038W",
        "gal1RGsig" : 1.3173E-10,
        "gal80Rexp" : -0.453,
        "gal1RGexp" : -0.652,
        "gal4RGsig" : 0.10377,
        "name" : "YAL038W",
        "COMMON" : "CDC19",
        "SUID" : 126,
        "gal4RGexp" : 0.123,
        "selected" : false,
        "gal80Rsig" : 1.5489E-7
      },
      "position" : {
        "x" : -548.44990312658,
        "y" : -1657.5782317675792
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "125",
        "shared_name" : "YNL307C",
        "gal1RGsig" : 0.27844,
        "gal80Rexp" : -0.063,
        "gal1RGexp" : -0.046,
        "gal4RGsig" : 0.029538,
        "name" : "YNL307C",
        "COMMON" : "MCK1",
        "SUID" : 125,
        "gal4RGexp" : 0.094,
        "selected" : false,
        "gal80Rsig" : 0.37572
      },
      "position" : {
        "x" : -487.98170244298626,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "123",
        "shared_name" : "YDL013W",
        "gal1RGsig" : 4.0439E-5,
        "gal80Rexp" : 0.593,
        "gal1RGexp" : 0.214,
        "gal4RGsig" : 0.22129,
        "name" : "YDL013W",
        "COMMON" : "HEX3",
        "SUID" : 123,
        "gal4RGexp" : 0.073,
        "selected" : false,
        "gal80Rsig" : 2.0836E-5
      },
      "position" : {
        "x" : -587.9817024429863,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "122",
        "shared_name" : "YER116C",
        "gal1RGsig" : 0.56099,
        "gal80Rexp" : 0.182,
        "gal1RGexp" : 0.029,
        "gal4RGsig" : 0.18379,
        "name" : "YER116C",
        "COMMON" : "YER116C",
        "SUID" : 122,
        "gal4RGexp" : -0.11,
        "selected" : false,
        "gal80Rsig" : 0.13915
      },
      "position" : {
        "x" : -687.9817024429863,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "120",
        "shared_name" : "YNR053C",
        "gal1RGsig" : 2.1301E-7,
        "gal80Rexp" : -0.012,
        "gal1RGexp" : 0.352,
        "gal4RGsig" : 0.0048783,
        "name" : "YNR053C",
        "COMMON" : "YNR053C",
        "SUID" : 120,
        "gal4RGexp" : -0.238,
        "selected" : false,
        "gal80Rsig" : 0.90581
      },
      "position" : {
        "x" : -787.9817024429863,
        "y" : 410.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "118",
        "shared_name" : "YLR264W",
        "gal1RGsig" : 1.6086E-4,
        "gal80Rexp" : -0.17,
        "gal1RGexp" : -0.259,
        "gal4RGsig" : 2.0632E-4,
        "name" : "YLR264W",
        "COMMON" : "RPS28B",
        "SUID" : 118,
        "gal4RGexp" : -0.299,
        "selected" : false,
        "gal80Rsig" : 0.21059
      },
      "position" : {
        "x" : 1012.0182975570137,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "115",
        "shared_name" : "YEL015W",
        "gal1RGsig" : 3.0657E-5,
        "gal80Rexp" : 0.275,
        "gal1RGexp" : 0.222,
        "gal4RGsig" : 0.0052925,
        "name" : "YEL015W",
        "COMMON" : "YEL015W",
        "SUID" : 115,
        "gal4RGexp" : -0.171,
        "selected" : false,
        "gal80Rsig" : 0.032829
      },
      "position" : {
        "x" : 912.0182975570137,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "113",
        "shared_name" : "YNL050C",
        "gal1RGsig" : 1.425E-5,
        "gal80Rexp" : 0.594,
        "gal1RGexp" : 0.301,
        "gal4RGsig" : 0.0031926,
        "name" : "YNL050C",
        "COMMON" : "YNL050C",
        "SUID" : 113,
        "gal4RGexp" : -0.448,
        "selected" : false,
        "gal80Rsig" : 7.5124E-4
      },
      "position" : {
        "x" : 812.0182975570137,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "111",
        "shared_name" : "YNR050C",
        "gal1RGsig" : 1.1825E-5,
        "gal80Rexp" : 0.647,
        "gal1RGexp" : 0.223,
        "gal4RGsig" : 0.0089039,
        "name" : "YNR050C",
        "COMMON" : "LYS9",
        "SUID" : 111,
        "gal4RGexp" : -0.131,
        "selected" : false,
        "gal80Rsig" : 1.1773E-7
      },
      "position" : {
        "x" : 712.0182975570137,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "110",
        "shared_name" : "YJR022W",
        "gal1RGsig" : 0.6011,
        "gal80Rexp" : 0.294,
        "gal1RGexp" : 0.059,
        "gal4RGsig" : 0.070701,
        "name" : "YJR022W",
        "COMMON" : "LSM8",
        "SUID" : 110,
        "gal4RGexp" : -0.435,
        "selected" : false,
        "gal80Rsig" : 0.14344
      },
      "position" : {
        "x" : 512.0182975570137,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "108",
        "shared_name" : "YOR167C",
        "gal1RGsig" : 2.7303E-6,
        "gal80Rexp" : -0.243,
        "gal1RGexp" : -0.374,
        "gal4RGsig" : 1.0533E-4,
        "name" : "YOR167C",
        "COMMON" : "RPS28A",
        "SUID" : 108,
        "gal4RGexp" : -0.239,
        "selected" : false,
        "gal80Rsig" : 4.8633E-5
      },
      "position" : {
        "x" : 412.01829755701374,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "107",
        "shared_name" : "YER112W",
        "gal1RGsig" : 7.0527E-5,
        "gal80Rexp" : 0.151,
        "gal1RGexp" : 0.193,
        "gal4RGsig" : 0.0037591,
        "name" : "YER112W",
        "COMMON" : "LSM4",
        "SUID" : 107,
        "gal4RGexp" : -0.181,
        "selected" : false,
        "gal80Rsig" : 0.13653
      },
      "position" : {
        "x" : 312.01829755701374,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "105",
        "shared_name" : "YCL067C",
        "gal1RGsig" : 0.0012873,
        "gal80Rexp" : 0.301,
        "gal1RGexp" : 0.169,
        "gal4RGsig" : 0.11481,
        "name" : "YCL067C",
        "COMMON" : "ALPHA2",
        "SUID" : 105,
        "gal4RGexp" : -0.085,
        "selected" : false,
        "gal80Rsig" : 0.0027555
      },
      "position" : {
        "x" : -663.4647041519706,
        "y" : -1124.8515080966197
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "103",
        "shared_name" : "YBR112C",
        "gal1RGsig" : 0.009167,
        "gal80Rexp" : 0.077,
        "gal1RGexp" : 0.108,
        "gal4RGsig" : 0.92034,
        "name" : "YBR112C",
        "COMMON" : "SSN6",
        "SUID" : 103,
        "gal4RGexp" : -0.004,
        "selected" : false,
        "gal80Rsig" : 0.17771
      },
      "position" : {
        "x" : -187.98170244298626,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "102",
        "shared_name" : "YCR084C",
        "gal1RGsig" : 0.28551,
        "gal80Rexp" : -0.091,
        "gal1RGexp" : 0.044,
        "gal4RGsig" : 1.832E-4,
        "name" : "YCR084C",
        "COMMON" : "TUP1",
        "SUID" : 102,
        "gal4RGexp" : 0.704,
        "selected" : false,
        "gal80Rsig" : 0.69411
      },
      "position" : {
        "x" : -287.98170244298626,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "100",
        "shared_name" : "YIL061C",
        "gal1RGsig" : 0.013072,
        "gal80Rexp" : 0.181,
        "gal1RGexp" : 0.165,
        "gal4RGsig" : 4.9035E-4,
        "name" : "YIL061C",
        "COMMON" : "SNP1",
        "SUID" : 100,
        "gal4RGexp" : -0.635,
        "selected" : false,
        "gal80Rsig" : 0.28119
      },
      "position" : {
        "x" : -387.98170244298626,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "99",
        "shared_name" : "YGR203W",
        "gal1RGsig" : 0.039575,
        "gal80Rexp" : -0.34,
        "gal1RGexp" : -0.141,
        "gal4RGsig" : 0.43554,
        "name" : "YGR203W",
        "COMMON" : "YGR203W",
        "SUID" : 99,
        "gal4RGexp" : -0.085,
        "selected" : false,
        "gal80Rsig" : 0.22451
      },
      "position" : {
        "x" : -487.98170244298626,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "94",
        "shared_name" : "YJL013C",
        "gal1RGsig" : 0.14469,
        "gal80Rexp" : 0.084,
        "gal1RGexp" : -0.072,
        "gal4RGsig" : 0.046575,
        "name" : "YJL013C",
        "COMMON" : "MAD3",
        "SUID" : 94,
        "gal4RGexp" : -0.154,
        "selected" : false,
        "gal80Rsig" : 0.52778
      },
      "position" : {
        "x" : -787.9817024429863,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "92",
        "shared_name" : "YGL229C",
        "gal1RGsig" : 2.3655E-9,
        "gal80Rexp" : -0.208,
        "gal1RGexp" : -0.521,
        "gal4RGsig" : 0.020857,
        "name" : "YGL229C",
        "COMMON" : "SAP4",
        "SUID" : 92,
        "gal4RGexp" : 0.171,
        "selected" : false,
        "gal80Rsig" : 0.28721
      },
      "position" : {
        "x" : -887.9817024429863,
        "y" : 310.51990667445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "91",
        "shared_name" : "YJL030W",
        "gal1RGsig" : 0.21701,
        "gal80Rexp" : 0.46,
        "gal1RGexp" : 0.08,
        "gal4RGsig" : 0.0092841,
        "name" : "YJL030W",
        "COMMON" : "MAD2",
        "SUID" : 91,
        "gal4RGexp" : -0.271,
        "selected" : false,
        "gal80Rsig" : 0.0045437
      },
      "position" : {
        "x" : 1012.0182975570137,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "89",
        "shared_name" : "YGR014W",
        "gal1RGsig" : 0.093717,
        "gal80Rexp" : -0.171,
        "gal1RGexp" : -0.066,
        "gal4RGsig" : 0.01294,
        "name" : "YGR014W",
        "COMMON" : "MSB2",
        "SUID" : 89,
        "gal4RGexp" : -0.131,
        "selected" : false,
        "gal80Rsig" : 0.031836
      },
      "position" : {
        "x" : 812.0182975570137,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "88",
        "shared_name" : "YPL211W",
        "gal1RGsig" : 0.0019352,
        "gal80Rexp" : 0.623,
        "gal1RGexp" : -0.231,
        "gal4RGsig" : 5.2826E-6,
        "name" : "YPL211W",
        "COMMON" : "NIP7",
        "SUID" : 88,
        "gal4RGexp" : -0.504,
        "selected" : false,
        "gal80Rsig" : 1.5609E-4
      },
      "position" : {
        "x" : 712.0182975570137,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "86",
        "shared_name" : "YGL044C",
        "gal1RGsig" : 0.0013639,
        "gal80Rexp" : 0.281,
        "gal1RGexp" : 0.162,
        "gal4RGsig" : 0.0040902,
        "name" : "YGL044C",
        "COMMON" : "RNA15",
        "SUID" : 86,
        "gal4RGexp" : -0.211,
        "selected" : false,
        "gal80Rsig" : 0.0057448
      },
      "position" : {
        "x" : 512.0182975570137,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "85",
        "shared_name" : "YOL123W",
        "gal1RGsig" : 9.8446E-6,
        "gal80Rexp" : -0.036,
        "gal1RGexp" : 0.245,
        "gal4RGsig" : 0.0050114,
        "name" : "YOL123W",
        "COMMON" : "HRP1",
        "SUID" : 85,
        "gal4RGexp" : 0.126,
        "selected" : false,
        "gal80Rsig" : 0.59496
      },
      "position" : {
        "x" : 412.01829755701374,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82",
        "shared_name" : "YAL003W",
        "gal1RGsig" : 0.0018696,
        "gal80Rexp" : -0.146,
        "gal1RGexp" : -0.157,
        "gal4RGsig" : 6.2814E-4,
        "name" : "YAL003W",
        "COMMON" : "EFB1",
        "SUID" : 82,
        "gal4RGexp" : -0.2,
        "selected" : false,
        "gal80Rsig" : 0.013062
      },
      "position" : {
        "x" : 312.01829755701374,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80",
        "shared_name" : "YFL017C",
        "gal1RGsig" : 0.0017854,
        "gal80Rexp" : 0.124,
        "gal1RGexp" : 0.131,
        "gal4RGsig" : 0.0055302,
        "name" : "YFL017C",
        "COMMON" : "GNA1",
        "SUID" : 80,
        "gal4RGexp" : 0.122,
        "selected" : false,
        "gal80Rsig" : 0.050323
      },
      "position" : {
        "x" : 112.01829755701374,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "78",
        "shared_name" : "YDR429C",
        "gal1RGsig" : 0.072655,
        "gal80Rexp" : 0.354,
        "gal1RGexp" : 0.078,
        "gal4RGsig" : 0.0011724,
        "name" : "YDR429C",
        "COMMON" : "TIF35",
        "SUID" : 78,
        "gal4RGexp" : -0.209,
        "selected" : false,
        "gal80Rsig" : 1.6643E-5
      },
      "position" : {
        "x" : -87.98170244298626,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "77",
        "shared_name" : "YMR146C",
        "gal1RGsig" : 0.30844,
        "gal80Rexp" : -0.151,
        "gal1RGexp" : -0.05,
        "gal4RGsig" : 0.0085173,
        "name" : "YMR146C",
        "COMMON" : "TIF34",
        "SUID" : 77,
        "gal4RGexp" : -0.143,
        "selected" : false,
        "gal80Rsig" : 0.072007
      },
      "position" : {
        "x" : -187.98170244298626,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "75",
        "shared_name" : "YLR293C",
        "gal1RGsig" : 1.7601E-5,
        "gal80Rexp" : -0.128,
        "gal1RGexp" : -0.242,
        "gal4RGsig" : 6.7968E-4,
        "name" : "YLR293C",
        "COMMON" : "GSP1",
        "SUID" : 75,
        "gal4RGexp" : -0.247,
        "selected" : false,
        "gal80Rsig" : 0.012703
      },
      "position" : {
        "x" : -387.98170244298626,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "73",
        "shared_name" : "YBR118W",
        "gal1RGsig" : 0.053125,
        "gal80Rexp" : 0.044,
        "gal1RGexp" : -0.074,
        "gal4RGsig" : 0.15497,
        "name" : "YBR118W",
        "COMMON" : "TEF2",
        "SUID" : 73,
        "gal4RGexp" : -0.063,
        "selected" : false,
        "gal80Rsig" : 0.54556
      },
      "position" : {
        "x" : -587.9817024429863,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "71",
        "shared_name" : "YPR080W",
        "gal1RGsig" : 9.8725E-4,
        "gal80Rexp" : -0.278,
        "gal1RGexp" : -0.138,
        "gal4RGsig" : 0.89728,
        "name" : "YPR080W",
        "COMMON" : "TEF1",
        "SUID" : 71,
        "gal4RGexp" : 0.009,
        "selected" : false,
        "gal80Rsig" : 6.7798E-4
      },
      "position" : {
        "x" : -687.9817024429863,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "70",
        "shared_name" : "YLR249W",
        "gal1RGsig" : 2.713E-8,
        "gal80Rexp" : -0.769,
        "gal1RGexp" : -0.39,
        "gal4RGsig" : 0.04747,
        "name" : "YLR249W",
        "COMMON" : "YEF3",
        "SUID" : 70,
        "gal4RGexp" : -0.394,
        "selected" : false,
        "gal80Rsig" : 0.035939
      },
      "position" : {
        "x" : -787.9817024429863,
        "y" : 210.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "68",
        "shared_name" : "YOR204W",
        "gal1RGsig" : 0.39944,
        "gal80Rexp" : -0.91,
        "gal1RGexp" : -0.033,
        "gal4RGsig" : 0.31268,
        "name" : "YOR204W",
        "COMMON" : "DED1",
        "SUID" : 68,
        "gal4RGexp" : -0.056,
        "selected" : false,
        "gal80Rsig" : 8.349E-16
      },
      "position" : {
        "x" : 1012.0182975570137,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "66",
        "shared_name" : "YGL097W",
        "gal1RGsig" : 0.0021913,
        "gal80Rexp" : 0.008,
        "gal1RGexp" : 0.16,
        "gal4RGsig" : 0.0022461,
        "name" : "YGL097W",
        "COMMON" : "SRM1",
        "SUID" : 66,
        "gal4RGexp" : -0.23,
        "selected" : false,
        "gal80Rsig" : 0.93826
      },
      "position" : {
        "x" : 712.0182975570137,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "65",
        "shared_name" : "YGR218W",
        "gal1RGsig" : 0.61381,
        "gal80Rexp" : -0.018,
        "gal1RGexp" : -0.018,
        "gal4RGsig" : 0.9794,
        "name" : "YGR218W",
        "COMMON" : "CRM1",
        "SUID" : 65,
        "gal4RGexp" : -0.001,
        "selected" : false,
        "gal80Rsig" : 0.80969
      },
      "position" : {
        "x" : 612.0182975570137,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "63",
        "shared_name" : "YGL122C",
        "gal1RGsig" : 8.7295E-4,
        "gal80Rexp" : 0.187,
        "gal1RGexp" : 0.174,
        "gal4RGsig" : 0.61707,
        "name" : "YGL122C",
        "COMMON" : "NAB2",
        "SUID" : 63,
        "gal4RGexp" : 0.02,
        "selected" : false,
        "gal80Rsig" : 0.0059966
      },
      "position" : {
        "x" : 412.01829755701374,
        "y" : 110.51990667445003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "62",
        "shared_name" : "YKR026C",
        "gal1RGsig" : 9.1177E-4,
        "gal80Rexp" : 0.292,
        "gal1RGexp" : -0.154,
        "gal4RGsig" : 3.5692E-6,
        "name" : "YKR026C",
        "COMMON" : "GCN3",
        "SUID" : 62,
        "gal4RGexp" : -0.501,
        "selected" : false,
        "gal80Rsig" : 0.011229
      },
      "position" : {
        "x" : 312.01829755701374,
        "y" : 110.51990667445003
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "668",
        "source" : "667",
        "target" : "286",
        "shared_name" : "YPR113W (pd) YMR043W",
        "name" : "YPR113W (pd) YMR043W",
        "interaction" : "pd",
        "SUID" : 668,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "664",
        "source" : "663",
        "target" : "262",
        "shared_name" : "YGR088W (pd) YLR256W",
        "name" : "YGR088W (pd) YLR256W",
        "interaction" : "pd",
        "SUID" : 664,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "642",
        "source" : "641",
        "target" : "330",
        "shared_name" : "YDL215C (pd) YER040W",
        "name" : "YDL215C (pd) YER040W",
        "interaction" : "pd",
        "SUID" : 642,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "631",
        "source" : "630",
        "target" : "231",
        "shared_name" : "YOR120W (pd) YPL248C",
        "name" : "YOR120W (pd) YPL248C",
        "interaction" : "pd",
        "SUID" : 631,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "622",
        "source" : "621",
        "target" : "604",
        "shared_name" : "YDR299W (pd) YJL194W",
        "name" : "YDR299W (pd) YJL194W",
        "interaction" : "pd",
        "SUID" : 622,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "657",
        "source" : "613",
        "target" : "301",
        "shared_name" : "YHR084W (pd) YFL026W",
        "name" : "YHR084W (pd) YFL026W",
        "interaction" : "pd",
        "SUID" : 657,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "656",
        "source" : "613",
        "target" : "295",
        "shared_name" : "YHR084W (pd) YDR461W",
        "name" : "YHR084W (pd) YDR461W",
        "interaction" : "pd",
        "SUID" : 656,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "605",
        "source" : "604",
        "target" : "286",
        "shared_name" : "YJL194W (pd) YMR043W",
        "name" : "YJL194W (pd) YMR043W",
        "interaction" : "pd",
        "SUID" : 605,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "595",
        "source" : "594",
        "target" : "350",
        "shared_name" : "YPR124W (pd) YMR021C",
        "name" : "YPR124W (pd) YMR021C",
        "interaction" : "pd",
        "SUID" : 595,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "574",
        "source" : "572",
        "target" : "410",
        "shared_name" : "YAR007C (pd) YPL111W",
        "name" : "YAR007C (pd) YPL111W",
        "interaction" : "pd",
        "SUID" : 574,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "542",
        "source" : "541",
        "target" : "344",
        "shared_name" : "YNL117W (pd) YJL089W",
        "name" : "YNL117W (pd) YJL089W",
        "interaction" : "pd",
        "SUID" : 542,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "503",
        "source" : "502",
        "target" : "196",
        "shared_name" : "YDR354W (pd) YEL009C",
        "name" : "YDR354W (pd) YEL009C",
        "interaction" : "pd",
        "SUID" : 503,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "498",
        "source" : "496",
        "target" : "225",
        "shared_name" : "YDR146C (pd) YGL035C",
        "name" : "YDR146C (pd) YGL035C",
        "interaction" : "pd",
        "SUID" : 498,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "497",
        "source" : "496",
        "target" : "286",
        "shared_name" : "YDR146C (pd) YMR043W",
        "name" : "YDR146C (pd) YMR043W",
        "interaction" : "pd",
        "SUID" : 497,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "495",
        "source" : "494",
        "target" : "286",
        "shared_name" : "YER111C (pd) YMR043W",
        "name" : "YER111C (pd) YMR043W",
        "interaction" : "pd",
        "SUID" : 495,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "491",
        "source" : "490",
        "target" : "128",
        "shared_name" : "YML024W (pd) YNL216W",
        "name" : "YML024W (pd) YNL216W",
        "interaction" : "pd",
        "SUID" : 491,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "562",
        "source" : "485",
        "target" : "225",
        "shared_name" : "YDR009W (pd) YGL035C",
        "name" : "YDR009W (pd) YGL035C",
        "interaction" : "pd",
        "SUID" : 562,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "478",
        "source" : "477",
        "target" : "448",
        "shared_name" : "YML123C (pd) YFR034C",
        "name" : "YML123C (pd) YFR034C",
        "interaction" : "pd",
        "SUID" : 478,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "711",
        "source" : "465",
        "target" : "430",
        "shared_name" : "YIL162W (pd) YNL167C",
        "name" : "YIL162W (pd) YNL167C",
        "interaction" : "pd",
        "SUID" : 711,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "449",
        "source" : "448",
        "target" : "147",
        "shared_name" : "YFR034C (pd) YBR093C",
        "name" : "YFR034C (pd) YBR093C",
        "interaction" : "pd",
        "SUID" : 449,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "447",
        "source" : "446",
        "target" : "286",
        "shared_name" : "YAL040C (pd) YMR043W",
        "name" : "YAL040C (pd) YMR043W",
        "interaction" : "pd",
        "SUID" : 447,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "431",
        "source" : "430",
        "target" : "199",
        "shared_name" : "YNL167C (pd) YOR202W",
        "name" : "YNL167C (pd) YOR202W",
        "interaction" : "pd",
        "SUID" : 431,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "629",
        "source" : "402",
        "target" : "507",
        "shared_name" : "YGL073W (pd) YER103W",
        "name" : "YGL073W (pd) YER103W",
        "interaction" : "pd",
        "SUID" : 629,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "628",
        "source" : "402",
        "target" : "598",
        "shared_name" : "YGL073W (pd) YHR055C",
        "name" : "YGL073W (pd) YHR055C",
        "interaction" : "pd",
        "SUID" : 628,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "627",
        "source" : "402",
        "target" : "596",
        "shared_name" : "YGL073W (pd) YHR053C",
        "name" : "YGL073W (pd) YHR053C",
        "interaction" : "pd",
        "SUID" : 627,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "403",
        "source" : "401",
        "target" : "402",
        "shared_name" : "YBR072W (pd) YGL073W",
        "name" : "YBR072W (pd) YGL073W",
        "interaction" : "pd",
        "SUID" : 403,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "395",
        "source" : "388",
        "target" : "158",
        "shared_name" : "YPL075W (pd) YOL086C",
        "name" : "YPL075W (pd) YOL086C",
        "interaction" : "pd",
        "SUID" : 395,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "394",
        "source" : "388",
        "target" : "156",
        "shared_name" : "YPL075W (pd) YDR050C",
        "name" : "YPL075W (pd) YDR050C",
        "interaction" : "pd",
        "SUID" : 394,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "391",
        "source" : "388",
        "target" : "133",
        "shared_name" : "YPL075W (pd) YHR174W",
        "name" : "YPL075W (pd) YHR174W",
        "interaction" : "pd",
        "SUID" : 391,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "390",
        "source" : "388",
        "target" : "131",
        "shared_name" : "YPL075W (pd) YGR254W",
        "name" : "YPL075W (pd) YGR254W",
        "interaction" : "pd",
        "SUID" : 390,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "389",
        "source" : "388",
        "target" : "129",
        "shared_name" : "YPL075W (pd) YCR012W",
        "name" : "YPL075W (pd) YCR012W",
        "interaction" : "pd",
        "SUID" : 389,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "398",
        "source" : "375",
        "target" : "225",
        "shared_name" : "? (pd) YGL035C",
        "name" : "? (pd) YGL035C",
        "interaction" : "pd",
        "SUID" : 398,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "376",
        "source" : "375",
        "target" : "236",
        "shared_name" : "? (pd) YKR099W",
        "name" : "? (pd) YKR099W",
        "interaction" : "pd",
        "SUID" : 376,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "599",
        "source" : "357",
        "target" : "598",
        "shared_name" : "YGL166W (pd) YHR055C",
        "name" : "YGL166W (pd) YHR055C",
        "interaction" : "pd",
        "SUID" : 599,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "597",
        "source" : "357",
        "target" : "596",
        "shared_name" : "YGL166W (pd) YHR053C",
        "name" : "YGL166W (pd) YHR053C",
        "interaction" : "pd",
        "SUID" : 597,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "352",
        "source" : "350",
        "target" : "351",
        "shared_name" : "YMR021C (pd) YLR214W",
        "name" : "YMR021C (pd) YLR214W",
        "interaction" : "pd",
        "SUID" : 352,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "349",
        "source" : "344",
        "target" : "348",
        "shared_name" : "YJL089W (pd) YLR377C",
        "name" : "YJL089W (pd) YLR377C",
        "interaction" : "pd",
        "SUID" : 349,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "347",
        "source" : "344",
        "target" : "291",
        "shared_name" : "YJL089W (pd) YKR097W",
        "name" : "YJL089W (pd) YKR097W",
        "interaction" : "pd",
        "SUID" : 347,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "346",
        "source" : "344",
        "target" : "345",
        "shared_name" : "YJL089W (pd) YER065C",
        "name" : "YJL089W (pd) YER065C",
        "interaction" : "pd",
        "SUID" : 346,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "334",
        "source" : "330",
        "target" : "333",
        "shared_name" : "YER040W (pd) YGR019W",
        "name" : "YER040W (pd) YGR019W",
        "interaction" : "pd",
        "SUID" : 334,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "332",
        "source" : "330",
        "target" : "331",
        "shared_name" : "YER040W (pd) YPR035W",
        "name" : "YER040W (pd) YPR035W",
        "interaction" : "pd",
        "SUID" : 332,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "329",
        "source" : "328",
        "target" : "286",
        "shared_name" : "YGL008C (pd) YMR043W",
        "name" : "YGL008C (pd) YMR043W",
        "interaction" : "pd",
        "SUID" : 329,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "324",
        "source" : "323",
        "target" : "312",
        "shared_name" : "YBL005W (pd) YJL219W",
        "name" : "YBL005W (pd) YJL219W",
        "interaction" : "pd",
        "SUID" : 324,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "510",
        "source" : "317",
        "target" : "286",
        "shared_name" : "YBR160W (pd) YMR043W",
        "name" : "YBR160W (pd) YMR043W",
        "interaction" : "pd",
        "SUID" : 510,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "585",
        "source" : "314",
        "target" : "323",
        "shared_name" : "YOL156W (pd) YBL005W",
        "name" : "YOL156W (pd) YBL005W",
        "interaction" : "pd",
        "SUID" : 585,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "614",
        "source" : "297",
        "target" : "613",
        "shared_name" : "YNL145W (pd) YHR084W",
        "name" : "YNL145W (pd) YHR084W",
        "interaction" : "pd",
        "SUID" : 614,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "612",
        "source" : "297",
        "target" : "105",
        "shared_name" : "YNL145W (pd) YCL067C",
        "name" : "YNL145W (pd) YCL067C",
        "interaction" : "pd",
        "SUID" : 612,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "302",
        "source" : "286",
        "target" : "301",
        "shared_name" : "YMR043W (pd) YFL026W",
        "name" : "YMR043W (pd) YFL026W",
        "interaction" : "pd",
        "SUID" : 302,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "300",
        "source" : "286",
        "target" : "299",
        "shared_name" : "YMR043W (pd) YJL157C",
        "name" : "YMR043W (pd) YJL157C",
        "interaction" : "pd",
        "SUID" : 300,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "298",
        "source" : "286",
        "target" : "297",
        "shared_name" : "YMR043W (pd) YNL145W",
        "name" : "YMR043W (pd) YNL145W",
        "interaction" : "pd",
        "SUID" : 298,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "296",
        "source" : "286",
        "target" : "295",
        "shared_name" : "YMR043W (pd) YDR461W",
        "name" : "YMR043W (pd) YDR461W",
        "interaction" : "pd",
        "SUID" : 296,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "294",
        "source" : "286",
        "target" : "293",
        "shared_name" : "YMR043W (pd) YGR108W",
        "name" : "YMR043W (pd) YGR108W",
        "interaction" : "pd",
        "SUID" : 294,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "292",
        "source" : "286",
        "target" : "291",
        "shared_name" : "YMR043W (pd) YKR097W",
        "name" : "YMR043W (pd) YKR097W",
        "interaction" : "pd",
        "SUID" : 292,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "290",
        "source" : "286",
        "target" : "289",
        "shared_name" : "YMR043W (pd) YJL159W",
        "name" : "YMR043W (pd) YJL159W",
        "interaction" : "pd",
        "SUID" : 290,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "288",
        "source" : "286",
        "target" : "287",
        "shared_name" : "YMR043W (pd) YIL015W",
        "name" : "YMR043W (pd) YIL015W",
        "interaction" : "pd",
        "SUID" : 288,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "285",
        "source" : "281",
        "target" : "225",
        "shared_name" : "YKL109W (pd) YGL035C",
        "name" : "YKL109W (pd) YGL035C",
        "interaction" : "pd",
        "SUID" : 285,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "284",
        "source" : "281",
        "target" : "265",
        "shared_name" : "YKL109W (pd) YJR048W",
        "name" : "YKL109W (pd) YJR048W",
        "interaction" : "pd",
        "SUID" : 284,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "272",
        "source" : "271",
        "target" : "265",
        "shared_name" : "YBL021C (pd) YJR048W",
        "name" : "YBL021C (pd) YJR048W",
        "interaction" : "pd",
        "SUID" : 272,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "270",
        "source" : "269",
        "target" : "265",
        "shared_name" : "YGL237C (pd) YJR048W",
        "name" : "YGL237C (pd) YJR048W",
        "interaction" : "pd",
        "SUID" : 270,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "268",
        "source" : "262",
        "target" : "267",
        "shared_name" : "YLR256W (pd) YEL039C",
        "name" : "YLR256W (pd) YEL039C",
        "interaction" : "pd",
        "SUID" : 268,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "266",
        "source" : "262",
        "target" : "265",
        "shared_name" : "YLR256W (pd) YJR048W",
        "name" : "YLR256W (pd) YJR048W",
        "interaction" : "pd",
        "SUID" : 266,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "264",
        "source" : "262",
        "target" : "263",
        "shared_name" : "YLR256W (pd) YML054C",
        "name" : "YLR256W (pd) YML054C",
        "interaction" : "pd",
        "SUID" : 264,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "577",
        "source" : "248",
        "target" : "410",
        "shared_name" : "YNL312W (pd) YPL111W",
        "name" : "YNL312W (pd) YPL111W",
        "interaction" : "pd",
        "SUID" : 577,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "571",
        "source" : "231",
        "target" : "233",
        "shared_name" : "YPL248C (pd) YBR018C",
        "name" : "YPL248C (pd) YBR018C",
        "interaction" : "pd",
        "SUID" : 571,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "570",
        "source" : "231",
        "target" : "229",
        "shared_name" : "YPL248C (pd) YLR081W",
        "name" : "YPL248C (pd) YLR081W",
        "interaction" : "pd",
        "SUID" : 570,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "569",
        "source" : "231",
        "target" : "227",
        "shared_name" : "YPL248C (pd) YBR020W",
        "name" : "YPL248C (pd) YBR020W",
        "interaction" : "pd",
        "SUID" : 569,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "567",
        "source" : "231",
        "target" : "483",
        "shared_name" : "YPL248C (pd) YML051W",
        "name" : "YPL248C (pd) YML051W",
        "interaction" : "pd",
        "SUID" : 567,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "566",
        "source" : "231",
        "target" : "225",
        "shared_name" : "YPL248C (pd) YGL035C",
        "name" : "YPL248C (pd) YGL035C",
        "interaction" : "pd",
        "SUID" : 566,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "565",
        "source" : "231",
        "target" : "265",
        "shared_name" : "YPL248C (pd) YJR048W",
        "name" : "YPL248C (pd) YJR048W",
        "interaction" : "pd",
        "SUID" : 565,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "564",
        "source" : "231",
        "target" : "375",
        "shared_name" : "YPL248C (pd) ?",
        "name" : "YPL248C (pd) ?",
        "interaction" : "pd",
        "SUID" : 564,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "563",
        "source" : "231",
        "target" : "222",
        "shared_name" : "YPL248C (pd) YBR019C",
        "name" : "YPL248C (pd) YBR019C",
        "interaction" : "pd",
        "SUID" : 563,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "561",
        "source" : "227",
        "target" : "225",
        "shared_name" : "YBR020W (pd) YGL035C",
        "name" : "YBR020W (pd) YGL035C",
        "interaction" : "pd",
        "SUID" : 561,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "466",
        "source" : "225",
        "target" : "465",
        "shared_name" : "YGL035C (pd) YIL162W",
        "name" : "YGL035C (pd) YIL162W",
        "interaction" : "pd",
        "SUID" : 466,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "464",
        "source" : "225",
        "target" : "348",
        "shared_name" : "YGL035C (pd) YLR377C",
        "name" : "YGL035C (pd) YLR377C",
        "interaction" : "pd",
        "SUID" : 464,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "463",
        "source" : "225",
        "target" : "137",
        "shared_name" : "YGL035C (pd) YLR044C",
        "name" : "YGL035C (pd) YLR044C",
        "interaction" : "pd",
        "SUID" : 463,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "234",
        "source" : "223",
        "target" : "233",
        "shared_name" : "YOL051W (pd) YBR018C",
        "name" : "YOL051W (pd) YBR018C",
        "interaction" : "pd",
        "SUID" : 234,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "230",
        "source" : "223",
        "target" : "229",
        "shared_name" : "YOL051W (pd) YLR081W",
        "name" : "YOL051W (pd) YLR081W",
        "interaction" : "pd",
        "SUID" : 230,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "228",
        "source" : "223",
        "target" : "227",
        "shared_name" : "YOL051W (pd) YBR020W",
        "name" : "YOL051W (pd) YBR020W",
        "interaction" : "pd",
        "SUID" : 228,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "226",
        "source" : "222",
        "target" : "225",
        "shared_name" : "YBR019C (pd) YGL035C",
        "name" : "YBR019C (pd) YGL035C",
        "interaction" : "pd",
        "SUID" : 226,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "224",
        "source" : "222",
        "target" : "223",
        "shared_name" : "YBR019C (pd) YOL051W",
        "name" : "YBR019C (pd) YOL051W",
        "interaction" : "pd",
        "SUID" : 224,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "538",
        "source" : "220",
        "target" : "537",
        "shared_name" : "YJR060W (pd) YPR167C",
        "name" : "YJR060W (pd) YPR167C",
        "interaction" : "pd",
        "SUID" : 538,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "207",
        "source" : "196",
        "target" : "206",
        "shared_name" : "YEL009C (pd) YMR300C",
        "name" : "YEL009C (pd) YMR300C",
        "interaction" : "pd",
        "SUID" : 207,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "205",
        "source" : "196",
        "target" : "204",
        "shared_name" : "YEL009C (pd) YOL058W",
        "name" : "YEL009C (pd) YOL058W",
        "interaction" : "pd",
        "SUID" : 205,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "203",
        "source" : "196",
        "target" : "202",
        "shared_name" : "YEL009C (pd) YBR248C",
        "name" : "YEL009C (pd) YBR248C",
        "interaction" : "pd",
        "SUID" : 203,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "201",
        "source" : "196",
        "target" : "143",
        "shared_name" : "YEL009C (pd) YCL030C",
        "name" : "YEL009C (pd) YCL030C",
        "interaction" : "pd",
        "SUID" : 201,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "200",
        "source" : "196",
        "target" : "199",
        "shared_name" : "YEL009C (pd) YOR202W",
        "name" : "YEL009C (pd) YOR202W",
        "interaction" : "pd",
        "SUID" : 200,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "198",
        "source" : "196",
        "target" : "197",
        "shared_name" : "YEL009C (pd) YMR108W",
        "name" : "YEL009C (pd) YMR108W",
        "interaction" : "pd",
        "SUID" : 198,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "557",
        "source" : "175",
        "target" : "286",
        "shared_name" : "YPR119W (pd) YMR043W",
        "name" : "YPR119W (pd) YMR043W",
        "interaction" : "pd",
        "SUID" : 557,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "315",
        "source" : "171",
        "target" : "314",
        "shared_name" : "YGL013C (pd) YOL156W",
        "name" : "YGL013C (pd) YOL156W",
        "interaction" : "pd",
        "SUID" : 315,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "313",
        "source" : "171",
        "target" : "312",
        "shared_name" : "YGL013C (pd) YJL219W",
        "name" : "YGL013C (pd) YJL219W",
        "interaction" : "pd",
        "SUID" : 313,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "404",
        "source" : "143",
        "target" : "236",
        "shared_name" : "YCL030C (pd) YKR099W",
        "name" : "YCL030C (pd) YKR099W",
        "interaction" : "pd",
        "SUID" : 404,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "221",
        "source" : "129",
        "target" : "220",
        "shared_name" : "YCR012W (pd) YJR060W",
        "name" : "YCR012W (pd) YJR060W",
        "interaction" : "pd",
        "SUID" : 221,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "159",
        "source" : "128",
        "target" : "158",
        "shared_name" : "YNL216W (pd) YOL086C",
        "name" : "YNL216W (pd) YOL086C",
        "interaction" : "pd",
        "SUID" : 159,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "157",
        "source" : "128",
        "target" : "156",
        "shared_name" : "YNL216W (pd) YDR050C",
        "name" : "YNL216W (pd) YDR050C",
        "interaction" : "pd",
        "SUID" : 157,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "155",
        "source" : "128",
        "target" : "154",
        "shared_name" : "YNL216W (pd) YOL127W",
        "name" : "YNL216W (pd) YOL127W",
        "interaction" : "pd",
        "SUID" : 155,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "153",
        "source" : "128",
        "target" : "126",
        "shared_name" : "YNL216W (pd) YAL038W",
        "name" : "YNL216W (pd) YAL038W",
        "interaction" : "pd",
        "SUID" : 153,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "152",
        "source" : "128",
        "target" : "151",
        "shared_name" : "YNL216W (pd) YIL069C",
        "name" : "YNL216W (pd) YIL069C",
        "interaction" : "pd",
        "SUID" : 152,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "150",
        "source" : "128",
        "target" : "149",
        "shared_name" : "YNL216W (pd) YER074W",
        "name" : "YNL216W (pd) YER074W",
        "interaction" : "pd",
        "SUID" : 150,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "148",
        "source" : "128",
        "target" : "147",
        "shared_name" : "YNL216W (pd) YBR093C",
        "name" : "YNL216W (pd) YBR093C",
        "interaction" : "pd",
        "SUID" : 148,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "144",
        "source" : "128",
        "target" : "143",
        "shared_name" : "YNL216W (pd) YCL030C",
        "name" : "YNL216W (pd) YCL030C",
        "interaction" : "pd",
        "SUID" : 144,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "142",
        "source" : "128",
        "target" : "141",
        "shared_name" : "YNL216W (pd) YNL301C",
        "name" : "YNL216W (pd) YNL301C",
        "interaction" : "pd",
        "SUID" : 142,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "140",
        "source" : "128",
        "target" : "139",
        "shared_name" : "YNL216W (pd) YOL120C",
        "name" : "YNL216W (pd) YOL120C",
        "interaction" : "pd",
        "SUID" : 140,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "138",
        "source" : "128",
        "target" : "137",
        "shared_name" : "YNL216W (pd) YLR044C",
        "name" : "YNL216W (pd) YLR044C",
        "interaction" : "pd",
        "SUID" : 138,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "136",
        "source" : "128",
        "target" : "135",
        "shared_name" : "YNL216W (pd) YIL133C",
        "name" : "YNL216W (pd) YIL133C",
        "interaction" : "pd",
        "SUID" : 136,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "134",
        "source" : "128",
        "target" : "133",
        "shared_name" : "YNL216W (pd) YHR174W",
        "name" : "YNL216W (pd) YHR174W",
        "interaction" : "pd",
        "SUID" : 134,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "132",
        "source" : "128",
        "target" : "131",
        "shared_name" : "YNL216W (pd) YGR254W",
        "name" : "YNL216W (pd) YGR254W",
        "interaction" : "pd",
        "SUID" : 132,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "130",
        "source" : "128",
        "target" : "129",
        "shared_name" : "YNL216W (pd) YCR012W",
        "name" : "YNL216W (pd) YCR012W",
        "interaction" : "pd",
        "SUID" : 130,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "482",
        "source" : "126",
        "target" : "388",
        "shared_name" : "YAL038W (pd) YPL075W",
        "name" : "YAL038W (pd) YPL075W",
        "interaction" : "pd",
        "SUID" : 482,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "322",
        "source" : "105",
        "target" : "301",
        "shared_name" : "YCL067C (pd) YFL026W",
        "name" : "YCL067C (pd) YFL026W",
        "interaction" : "pd",
        "SUID" : 322,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "321",
        "source" : "105",
        "target" : "295",
        "shared_name" : "YCL067C (pd) YDR461W",
        "name" : "YCL067C (pd) YDR461W",
        "interaction" : "pd",
        "SUID" : 321,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "319",
        "source" : "105",
        "target" : "287",
        "shared_name" : "YCL067C (pd) YIL015W",
        "name" : "YCL067C (pd) YIL015W",
        "interaction" : "pd",
        "SUID" : 319,
        "shared_interaction" : "pd",
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}